/* ============================================================================
   ステージ：第一話 ── おばあさんの家の前  id = 'house_front'
   種類：story　家に入る前の場面（分かれ道で選んだ道で、中身が変わる）
   担当：
   ----------------------------------------------------------------------------
   ◆ このステージの流れ
     近道（flags.route==='shortcut'）
       少年はひとり。戸が少し開いていて、中から物音がする。垣根のそばにマリがいる。
       マリに話しかけると、右の端（戸）から中へ入れる。
     遠回り（flags.route==='detour'）
       赤ずきんと一緒。赤ずきんに話しかけると戸を叩き、中から低い声。
       「赤ずきんを止める／何もしない」を選ぶ（flags.stoppedAtDoor）。
         止められるのは、狼のことを伝えていた（flags.warnedHood）か、
         ここで「気づいたこと」を 2つ以上見つけていたとき。
       止められなかったときは、赤ずきんが先に中へ入っていく。
     どちらの道でも、まわりを見ると「気づいたこと」が見つかる（3つ。見なくても進める）
       ・戸口へ続く獣の足あと　・ひびの入った眼鏡　・窓の中（窓の下の樽に乗る）
       見つけた数は flags.houseClues に入る。
   ここで決めた flags.stoppedAtDoor は、次の「おばあさんの家」（12_grannys_house.js）で使われます。
   ========================================================================== */
(function(){
const ctx=GT.ctx, W=GT.W, H=GT.H, EDGE=GT.EDGE, FLOOR=H-GT.EDGE, SPINE=GT.SPINE;
const WALL ={page:'left',  x:210, y:424, w:96, h:40, kind:'ledge'};   // 石垣
const BUTT ={page:'right', x:560, y:412, w:44, h:52, kind:'ledge'};   // 窓の下の雨水の樽
const WIN  ={x:568, y:322, w:60, h:50};                               // 家の窓
const DOOR ={x:806, y:362, w:52};                                     // 家の戸（右の端）
const PRINTS={x:470, w:300};                                          // 獣の足あと
const GLASSES_X=716;                                                  // 落ちている眼鏡
const MARI_GATE=372, HOOD_DOOR=742;

// --- 地形 ------------------------------------------------------------------
GT.defineStage('house_front', {
  platforms:[ WALL, BUTT ],
  boxes:[], enemies:[],
  decor:[
    {layer:'back',  kind:'tree',  x:250, y:130, w:110, h:290},
    {layer:'back',  kind:'bush',  x:20,  y:420, w:90,  h:44},
    {layer:'back',  kind:'bush',  x:110, y:424, w:80,  h:40},
    {layer:'front', kind:'grass', x:150, y:434, w:60,  h:30},
    {layer:'front', kind:'grass', x:470, y:434, w:60,  h:30},
    {layer:'front', kind:'fern',  x:-8,  y:398, w:76,  h:70},
  ],
});

// --- セリフ ----------------------------------------------------------------
const OPEN={
  shortcut:[
    {s:'',c:'narr',t:'少年は、ひとりで駆けてきた。息が切れる。'},
    {s:'',c:'narr',t:'家の戸が、少しだけ開いている。中から、ガタン、と物音がした。'},
    {s:'',c:'narr',t:'垣根のそばに、マリが立っている。'},
  ],
  detour:[
    {s:'赤ずきん',c:'hood',t:'着いた！　ここが、おばあちゃんのお家。'},
    {s:'赤ずきん',c:'hood',t:'……あれ？　いつもなら、窓から手を振ってくれるのに。'},
    {s:'',c:'narr',t:'（まわりをよく見てから、赤ずきんに話しかけよう）'},
  ],
};
const MARI_LINES=[
  {s:'マリ',c:'mari',t:'……来たんだ。ひとりで。'},
  {s:'マリ',c:'mari',t:'聞こえる？　中の音。'},
  {s:'マリ',c:'mari',t:'まだ、間に合う。……たぶん。'},
  {s:'マリ',c:'mari',t:'戸は、あなたが開けて。'},
];
const KNOCK=[
  {s:'赤ずきん',c:'hood',t:'じゃあ、戸を叩くね。'},
  {s:'',c:'narr',t:'赤ずきんが、戸を叩く。',act:'front-knock'},
  {s:'赤ずきん',c:'hood',t:'おばあちゃん、わたしよ。ガレットとバターの壺を持ってきたの。'},
  {s:'狼',c:'wolf',t:'（中から、しわがれ声で）掛け金を引いて、戸を開けてちょうだい。'},
  {s:'',c:'narr',t:'……おばあさんの声にしては、低すぎる。'},
  {s:'',c:'narr',t:'赤ずきんが、掛け金に手を伸ばす。'},
];
const canStop=()=> GT.flags.warnedHood || clueCount()>=2;
const KNOCK_CHOICES=[
  { label:'赤ずきんを止める', set:()=>{ GT.flags.stoppedAtDoor = canStop(); }, after:()=>{
      if(GT.flags.warnedHood) return [
        {s:'',c:'narr',t:'少年が手を掴む。'},
        {s:'赤ずきん',c:'hood',t:'……どうしたの？'},
        {s:'',c:'narr',t:'少年が戸を指し、首を振る。'},
        {s:'赤ずきん',c:'hood',t:'……分かった。'},
      ];
      if(canStop()) return [
        {s:'',c:'narr',t:'少年が手を掴む。そして、見てきたものを指さした。'+foundText()+'。'},
        ...(st.found.glasses?[{s:'赤ずきん',c:'hood',t:'……これ、おばあちゃんの眼鏡……？'}]:[]),
        {s:'赤ずきん',c:'hood',t:'……分かった。あなたが、先に。'},
      ];
      return [
        {s:'',c:'narr',t:'少年が手を伸ばす。だが、赤ずきんはもう掛け金を引いていた。'},
        {s:'赤ずきん',c:'hood',t:'……？　おばあちゃん、待たせちゃ悪いもの。'},
        {s:'',c:'narr',t:'止める間もなく、赤ずきんは先に中へ入っていく。',act:'front-hood-enter'},
      ];
    }},
  { label:'何もしない', set:()=>{ GT.flags.stoppedAtDoor=false; }, after:[
      {s:'',c:'narr',t:'赤ずきんが掛け金を引き、中へ入っていく。少年もあとに続いた。',act:'front-hood-enter'},
    ]},
];
const CLUES=[
  { key:'prints', text:'戸口へ続く足あと', lines:()=>[
    {s:'',c:'narr',t:'大きな獣の足あとが、まっすぐ戸口へ続いている。'},
    ...(GT.flags.route==='shortcut'?[{s:'',c:'narr',t:'まだ新しい。土が、湿っている。'}]:[{s:'',c:'narr',t:'足あとの上を、もう落ち葉がおおいはじめている。'}]) ]},
  { key:'glasses', text:'ひびの入った眼鏡', lines:()=>[
    {s:'',c:'narr',t:'戸口の前に、丸い眼鏡が落ちている。片方のレンズに、ひびが入っていた。'} ]},
  { key:'window', text:'窓の中', lines:()=> GT.flags.route==='shortcut' ? [
    {s:'',c:'narr',t:'窓の向こうで、大きな影が、ベッドの上の小さな人影に覆いかぶさろうとしている。'},
    {s:'',c:'narr',t:'……急がないと！'} ] : [
    {s:'',c:'narr',t:'カーテンのすきまから、中をのぞく。ベッドのふくらみが、ゆっくりと上下している。'},
    {s:'',c:'narr',t:'……おばあさんにしては、大きすぎる。'} ]},
];
const clueCount=()=>CLUES.filter(c=>st.found[c.key]).length;
const foundText=()=>CLUES.filter(c=>st.found[c.key]).map(c=>c.text).join('、');

// --- シーン ----------------------------------------------------------------
GT.registerScene({
  id:'house_front', type:'story', stage:'house_front', label:'第一話 ── おばあさんの家の前',
  intro:[
    {s:'',c:'narr',t:'風車小屋を過ぎると、村のいちばん端に、小さな石の家が見えてきた。',act:'front-setup'},
    {s:'',c:'narr',t:'日が、傾きはじめている。'},
  ],
  npcs:[
    // 遠回りのときだけ：赤ずきん（話しかけると戸を叩く）
    { who:'hood', name:'赤ずきん', page:'left', x:-300, lines:KNOCK, choices:KNOCK_CHOICES,
      onEnd:()=>{ st.talked=true; GT.fillPage('front', GT.flags.stoppedAtDoor
        ? '——戸の向こうの声は、おばあさんのものではなかった。少年は、赤ずきんを止めた。'
        : '——赤ずきんは掛け金を引き、おばあさんの家へ入っていった。'); } },
    // 近道のときだけ：マリ
    { who:'mari', name:'マリ', page:'left', x:-300, lines:MARI_LINES,
      onEnd:()=>{ st.talked=true; GT.fillPage('front','——少年は、ひとりでおばあさんの家にたどり着いた。戸の向こうから、物音がしていた。'); } },
  ],
});

/* ==========================================================================
   進行
   ========================================================================== */
const st={ talked:false, busy:false, opened:false, found:{}, hoodEnterT0:0, knockT0:0, last:performance.now() };
const isFront=()=>GT.scene&&GT.scene.id==='house_front';
const npc=who=>GT.getNpcs().find(n=>n.who===who);
const shortcut=()=>GT.flags.route==='shortcut';
GT.registerSceneReset(()=>{ if(!isFront()) return;
  st.talked=false; st.busy=false; st.opened=false; st.found={}; st.hoodEnterT0=0; st.knockT0=0; GT.flags.houseClues=0; });
GT.registerAct('front-setup',()=>{
  const h=npc('hood'), m=npc('mari');
  if(shortcut()){ if(m) m.x=MARI_GATE; }
  else { if(h) h.x=EDGE; GT.flags.stoppedAtDoor=false; }
});
GT.registerAct('front-knock',()=>{ st.knockT0=performance.now(); });
GT.registerAct('front-hood-enter',()=>{ st.hoodEnterT0=performance.now(); });

function autoTalk(lines){
  st.busy=true; GT.mode='idle'; GT.player.vx=0;
  GT.beginDialogue(lines,null,()=>{ GT.hideDialogue(); GT.mode='play'; st.busy=false; });
}
GT.registerUpdate(()=>{
  if(!isFront() || st.busy) return;
  const pl=GT.player, pcx=pl.x+pl.w/2;
  if(!st.opened){ st.opened=true; autoTalk(OPEN[shortcut()?'shortcut':'detour']); return; }
  // 気づいたこと
  const onFloor = pl.onGround && Math.abs(pl.y+pl.h-FLOOR)<2;
  const spots={
    prints:  onFloor && pcx>PRINTS.x+30 && pcx<PRINTS.x+110,
    glasses: onFloor && Math.abs(pcx-GLASSES_X)<22,
    window:  pl.onGround && Math.abs(pl.y+pl.h-BUTT.y)<2 && pcx>BUTT.x-6 && pcx<BUTT.x+BUTT.w+6,
  };
  for(const c of CLUES){
    if(!st.found[c.key] && spots[c.key]){ st.found[c.key]=true; GT.flags.houseClues=clueCount(); autoTalk(c.lines()); return; }
  }
});

/* 赤ずきんの動き（話す前はついてくる／戸を叩くときは戸の前／止めたあとはついてくる／入るときは戸の中へ） */
function moveHood(){
  const h=npc('hood'); if(!h || shortcut()) return;
  const now=performance.now(), dt=Math.min(0.05,(now-st.last)/1000); st.last=now;
  if(st.hoodEnterT0){ if(h.x<DOOR.x+10) h.x+=Math.min(140*dt,DOOR.x+10-h.x); else h.x=-300; return; }
  if(h.x<-100) return;
  const pcx=GT.player.x+GT.player.w/2;
  const target = (st.knockT0 && !st.talked) ? HOOD_DOOR : pcx+(pcx>h.x+16?-42:42)-16;
  if(GT.mode!=='play' && !st.knockT0) return;
  const dx=target-h.x; if(Math.abs(dx)>6) h.x+=Math.sign(dx)*Math.min(200*dt,Math.abs(dx));
}

/* ==========================================================================
   描画
   ========================================================================== */
function ell(x,y,rx,ry,c){ ctx.beginPath(); ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); }

/* 夕暮れの空・遠くの風車小屋・家（地形より奥） */
function drawBack(){
  const t=performance.now()/1000;
  ctx.save();
  const sky=ctx.createLinearGradient(0,EDGE,0,FLOOR);
  sky.addColorStop(0,'rgba(214,120,90,0.30)'); sky.addColorStop(0.5,'rgba(230,170,110,0.18)'); sky.addColorStop(1,'rgba(230,170,110,0)');
  ctx.fillStyle=sky; ctx.fillRect(0,0,W,H);
  // 遠くの丘と、通りすぎてきた風車小屋
  ctx.fillStyle='rgba(110,100,80,0.30)';
  ctx.beginPath(); ctx.moveTo(0,FLOOR); ctx.quadraticCurveTo(160,300,420,360); ctx.lineTo(420,FLOOR); ctx.closePath(); ctx.fill();
  const mx=120, my=300;
  ctx.fillStyle='rgba(90,72,56,0.6)';
  ctx.beginPath(); ctx.moveTo(mx-12,my+40); ctx.lineTo(mx-8,my); ctx.lineTo(mx+8,my); ctx.lineTo(mx+12,my+40); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.translate(mx,my+2); ctx.rotate(t*0.5); ctx.fillStyle='rgba(232,220,192,0.7)';
  for(let i=0;i<4;i++){ ctx.rotate(Math.PI/2); ctx.fillRect(-1.5,-26,3,24); ctx.fillRect(1,-26,5,18); }
  ctx.restore();
  // 垣根と門（左ページ）
  ctx.fillStyle='#4f5d41';
  for(let x=330;x<450;x+=22) ell(x,FLOOR-22,16,24,'#4f5d41');
  ctx.fillStyle='#6b4f36'; ctx.fillRect(312,392,8,FLOOR-392);
  drawHouse(t);
  // 足あと
  for(let i=0;i<8;i++){ const x=PRINTS.x+12+i*36, y=FLOOR-3+(i%2);
    ell(x,y,6,2.4,'rgba(40,32,24,0.5)'); for(let k=-1;k<=1;k++) ell(x+5+k*4,y-3,1.6,1.2,'rgba(40,32,24,0.5)'); }
  // 眼鏡
  ctx.strokeStyle='#5a4630'; ctx.lineWidth=1.4;
  ctx.beginPath(); ctx.arc(GLASSES_X-5,FLOOR-4,4,0,Math.PI*2); ctx.arc(GLASSES_X+5,FLOOR-4,4,0,Math.PI*2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(GLASSES_X+3,FLOOR-7); ctx.lineTo(GLASSES_X+7,FLOOR-2); ctx.stroke();
  ctx.restore();
}
function drawHouse(t){
  // 家の後ろの三本の樫
  [[560,160,70],[690,130,80],[830,150,72]].forEach(([x,y,r])=>{ ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fillStyle='rgba(63,74,52,0.85)'; ctx.fill(); });
  // 煙突と煙
  ctx.fillStyle='#6f6659'; ctx.fillRect(760,214,22,50);
  for(let i=0;i<5;i++){ const k=((t*0.2)+i/5)%1; ctx.globalAlpha=0.3*(1-k); ell(771+k*20,206-k*110,5+k*12,4+k*10,'#efe6d2'); }
  ctx.globalAlpha=1;
  // 石の壁
  ctx.fillStyle='#a69c8a'; ctx.fillRect(526,296,W-EDGE-526,FLOOR-296);
  ctx.strokeStyle='rgba(70,62,50,0.35)'; ctx.lineWidth=1;
  for(let row=0, y=296; y<FLOOR; row++, y+=16){ ctx.beginPath(); ctx.moveTo(526,y); ctx.lineTo(W-EDGE,y); ctx.stroke();
    for(let x=526+(row%2)*14; x<W-EDGE; x+=28){ ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x,y+16); ctx.stroke(); } }
  // わらぶき屋根
  ctx.beginPath(); ctx.moveTo(506,302); ctx.lineTo(712,190); ctx.lineTo(W+20,302); ctx.closePath();
  ctx.fillStyle='#b08d57'; ctx.fill();
  ctx.strokeStyle='rgba(90,70,40,0.4)'; ctx.lineWidth=1.2;
  for(let i=0;i<26;i++){ const x=520+i*16; ctx.beginPath(); ctx.moveTo(x,302); ctx.lineTo(x+(712-x)*0.25,302-(302-190)*0.25*(1-Math.abs(x-712)/220)); ctx.stroke(); }
  // つた
  ctx.strokeStyle='#57644a'; ctx.lineWidth=2;
  ctx.beginPath(); ctx.moveTo(532,FLOOR); ctx.quadraticCurveTo(548,380,538,320); ctx.stroke();
  for(let i=0;i<7;i++) ell(536+(i%2)*8,FLOOR-14-i*20,5,3,'#57644a');
  // 窓
  const w=WIN, sc=shortcut();
  ctx.fillStyle='#4a3a28'; ctx.fillRect(w.x-5,w.y-5,w.w+10,w.h+10);
  ctx.fillStyle= sc ? `rgba(255,190,110,${0.8+0.1*Math.sin(t*9)})` : '#3a3530'; ctx.fillRect(w.x,w.y,w.w,w.h);
  if(sc){ // 覆いかぶさる大きな影
    ctx.save(); ctx.beginPath(); ctx.rect(w.x,w.y,w.w,w.h); ctx.clip();
    const lean=Math.sin(t*1.6)*4;
    ctx.fillStyle='rgba(40,28,22,0.75)';
    ctx.beginPath(); ctx.ellipse(w.x+34+lean,w.y+30,20,16,-0.3,0,Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(w.x+44+lean,w.y+18); ctx.lineTo(w.x+50+lean,w.y+6); ctx.lineTo(w.x+54+lean,w.y+20); ctx.fill();
    ell(w.x+14,w.y+44,9,5,'rgba(70,60,80,0.6)');
    ctx.restore();
  } else { // 閉じたカーテン
    ctx.fillStyle='#8b5e63'; ctx.fillRect(w.x,w.y,w.w/2-2,w.h); ctx.fillRect(w.x+w.w/2+2,w.y,w.w/2-2,w.h);
  }
  ctx.fillStyle='#4a3a28'; ctx.fillRect(w.x+w.w/2-2,w.y,4,w.h);
  drawDoor(t);
}
function drawDoor(t){
  const d=DOOR, r=d.w/2, top=d.y+r;
  const arch=()=>{ ctx.beginPath(); ctx.moveTo(d.x,FLOOR); ctx.lineTo(d.x,top); ctx.arc(d.x+r,top,r,Math.PI,0); ctx.lineTo(d.x+d.w,FLOOR); ctx.closePath(); };
  ctx.fillStyle='#5a4630'; ctx.fillRect(d.x-5,d.y-4,d.w+10,FLOOR-d.y+4);
  // 開く量：近道ははじめから少し開いている。赤ずきんが入るときは大きく開く
  let open = shortcut() ? 0.25 : 0;
  if(st.hoodEnterT0){ const k=(performance.now()-st.hoodEnterT0)/1000; open=Math.max(open, k<0.4?k/0.4:k<2.2?1:Math.max(0,1-(k-2.2)/0.5)); }
  arch(); ctx.fillStyle = shortcut() ? '#ffcf86' : '#2a221a'; ctx.fill();
  ctx.save(); arch(); ctx.clip();
  const pw=d.w*(1-open*0.8);
  ctx.fillStyle='#5e3a28'; ctx.fillRect(d.x,d.y,pw,FLOOR-d.y);
  ctx.strokeStyle='rgba(30,18,10,0.4)'; ctx.lineWidth=1.5;
  for(let i=1;i<4;i++){ const x=d.x+pw*i/4; ctx.beginPath(); ctx.moveTo(x,d.y); ctx.lineTo(x,FLOOR); ctx.stroke(); }
  ell(d.x+pw-8,d.y+56,2.6,2.6,'#d9b877');
  ctx.restore();
}

/* 樽と石垣の見た目・物音・気づいたことの表示（プレイヤーより奥） */
function drawFront(){
  moveHood();
  const t=performance.now()/1000;
  ctx.save();
  // 雨水の樽
  const b=BUTT;
  GT.roundRect(b.x,b.y,b.w,b.h,9); ctx.fillStyle='#7a5434'; ctx.fill();
  ctx.fillStyle='#3e3223'; ctx.fillRect(b.x,b.y+9,b.w,4); ctx.fillRect(b.x,b.y+b.h-13,b.w,4);
  ell(b.x+b.w/2,b.y+3,b.w/2-2,3,'rgba(120,150,160,0.9)');
  // 石垣
  const s=WALL; ctx.fillStyle='#8a8070'; GT.roundRect(s.x,s.y,s.w,s.h,6); ctx.fill();
  ctx.strokeStyle='rgba(50,44,36,0.45)'; ctx.lineWidth=1.2;
  for(let row=0;row<3;row++){ const y=s.y+row*13; ctx.beginPath(); ctx.moveTo(s.x,y); ctx.lineTo(s.x+s.w,y); ctx.stroke();
    for(let x=s.x+((row%2)?12:24);x<s.x+s.w;x+=24){ ctx.beginPath(); ctx.moveTo(x,y); ctx.lineTo(x,y+13); ctx.stroke(); } }
  // 近道：戸の向こうの物音
  if(shortcut() && (t%3.2)<0.7){
    ctx.globalAlpha=1-(t%3.2)/0.7; ctx.font="700 16px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.fillStyle='#8b3a2f';
    ctx.fillText((Math.floor(t/3.2)%2)?'ガタン！':'ドン……',DOOR.x+DOOR.w/2,DOOR.y-14); ctx.globalAlpha=1; }
  // 赤ずきんが戸を叩く音
  if(st.knockT0){ const k=(performance.now()-st.knockT0)/1000; if(k<1.2){
    ctx.globalAlpha=1-k/1.2; ctx.font="700 15px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.fillStyle='#5a4630';
    ctx.fillText('コン、コン',DOOR.x+DOOR.w/2-10,DOOR.y-14-k*10); ctx.globalAlpha=1; } }
  // 気づいたこと
  const n=clueCount();
  if(st.opened){
    ctx.font="700 14px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.textBaseline='middle';
    const txt='気づいたこと　'+CLUES.map(c=>st.found[c.key]?'●':'○').join(' ');
    const w=ctx.measureText(txt).width+28;
    GT.roundRect(W/2-w/2,35,w,26,13); ctx.fillStyle='rgba(43,36,24,0.78)'; ctx.fill();
    ctx.fillStyle='#f3ead0'; ctx.fillText(txt,W/2,49);
    if(n<3){ const mark=(x,y)=>{ ctx.globalAlpha=0.6+0.35*Math.sin(t*3+x); ctx.fillStyle='#a8463a';
        ctx.font="700 22px 'Zen Old Mincho',serif"; ctx.fillText('？',x,y); ctx.globalAlpha=1; };
      if(!st.found.prints)  mark(PRINTS.x+70,FLOOR-26);
      if(!st.found.glasses) mark(GLASSES_X,FLOOR-26);
      if(!st.found.window)  mark(WIN.x+WIN.w/2,WIN.y-16); }
  }
  ctx.restore();
}

GT.registerDraw(()=>{ if(!isFront()) return; drawBack(); }, 'back');
GT.registerDraw(()=>{ if(!isFront()) return; drawFront(); }, 'world');
})();
