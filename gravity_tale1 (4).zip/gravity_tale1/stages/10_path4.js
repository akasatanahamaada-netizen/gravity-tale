/* ============================================================================
   ステージ：第一話 ── 遠回りの道 ②  id = 'path4'
   種類：play　分かれ道で「遠回り」を選んだときだけ遊ぶ（近道のときは飛ばす）
   担当：
   ========================================================================== */

GT.defineStage('path4', {
   platforms:[
    {page:'left', x:190, y:160, w:100, h:65, kind:'ledge'},
    {page:'left', x:230, y:270, w:25, h:195, kind:'ledge'},
    {page:'left', x:380, y:20, w:55, h:110, kind:'ledge'},
    {page:'right', x:690, y:20, w:60, h:90, kind:'ledge'},
    {page:'left', x:420, y:20, w:20, h:210, kind:'ledge'},
    {page:'right', x:770, y:390, w:60, h:70, kind:'ledge'},
    {page:'right', x:700, y:320, w:110, h:140, kind:'ledge'},
    {page:'right', x:610, y:20, w:100, h:130, kind:'ledge'},
    {page:'left', x:170, y:220, w:140, h:90, kind:'ledge'},
    {page:'left', x:320, y:430, w:50, h:30, kind:'ledge'},
    {page:'left', x:430, y:20, w:20, h:170, kind:'ledge'},
    {page:'right', x:570, y:20, w:70, h:60, kind:'ledge'},
  ],
  boxes:[
  ],
  enemies:[
    {page:'left', x:210, y:140, w:35, h:20, dir:-1},
    {page:'right', x:630, y:430, w:40, h:30, dir:-1},
  ],
  swamps:[
    {page:'right', x:360, y:440, w:250, h:20},
  ],
  decor:[
    {layer:'front', kind:'fern', x:90, y:390, w:60, h:70},
    {layer:'front', kind:'fern', x:510, y:390, w:70, h:70},
    {layer:'front', kind:'fern', x:250, y:390, w:70, h:70},
    {layer:'front', kind:'fern', x:600, y:380, w:80, h:80},
    {layer:'front', kind:'fern', x:420, y:390, w:70, h:70},
  ],
});

GT.registerScene({
  id:'path4', type:'play', stage:'path4', clear:'exit',
  label:'第一話 ── 遠回りの道 ②',
  intro:{s:'',c:'narr',t:'右へ進もう。'},
  dynamic:'detourOnly',     // 遠回りのときだけ遊ぶ（07_crossroads.js）
});
