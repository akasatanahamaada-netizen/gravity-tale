/* ============================================================================
   ステージ：第一話 ── 狼  id = 'wolf_talk'
   種類：story　狼に話しかける。「危険を告げるか」で分岐（flags.warnedHood）
   担当：
   ----------------------------------------------------------------------------
   分岐の作り方：npc の choices に選択肢を並べ、set でフラグを立てる。
   ここで立てた flags.warnedHood は、後の「おばあさんの家」で使われます。

   ◆ このステージの流れ
     1) 暗い森の奥。赤ずきんが少年のうしろをついてくる。
     2) 右ページに入ると、茂みが揺れて、狼が現れる（自動）。赤ずきんは狼のそばへ。
     3) 狼に話しかける前に、まわりを見ると「違和感」が見つかる（3つ。見なくても進める）
          ・道の上の大きな足あと（左ページ・背表紙の手前）
          ・木の幹の爪あと（左ページ。切り株 → 枝に乗って、近くで見る）
          ・狼の影（右ページ・狼のうしろ）……みんなの影はふつうなのに、狼の影だけ口を開けている
     4) 狼に話しかける → 狼は脇道へ去る → 「赤ずきんに伝えるか」を選ぶ
        見つけた違和感が多いほど、伝えたときの赤ずきんの反応が変わる。
        見つけた数は GT.flags.wolfClues に入る（0〜3）。

   ◆ このファイルが持っている独自の仕掛け（engine.js は触らない）
     act：'wolf-setup'（はじめの位置）/ 'wolf-leave'（狼が脇道へ去る）
     GT.registerUpdate        … 赤ずきんがついてくる・狼の登場・違和感を見つける
     GT.registerDraw          … 暗い森・霧・茂み・爪あと・足あと・影・違和感の表示
   ========================================================================== */
(function(){
const ctx=GT.ctx, W=GT.W, H=GT.H, EDGE=GT.EDGE, FLOOR=H-GT.EDGE, SPINE=GT.SPINE;
const WOLF_HIDE=820, WOLF_STAND=700, HOOD_BY_WOLF=610;
const STUMP ={page:'left', x:226, y:420, w:48, h:44, kind:'ledge'};
const BRANCH={page:'left', x:96,  y:372, w:94, h:14, kind:'ledge'};
const TRUNK ={x:140, w:40, top:96};        // 爪あとのある木
const PRINTS={x:330, w:100};               // 足あと
const BUSH  ={x:760, w:130};               // 狼が隠れている茂み

// --- 地形 ------------------------------------------------------------------
GT.defineStage('wolf_talk', {
  platforms:[ STUMP, BRANCH ],
  boxes:[], enemies:[],
  decor:[
    {layer:'back',  kind:'tree',  x:250, y:90,  w:110, h:330},
    {layer:'back',  kind:'tree',  x:480, y:70,  w:120, h:350},
    {layer:'back',  kind:'tree',  x:610, y:120, w:90,  h:300},
    {layer:'back',  kind:'rock',  x:420, y:430, w:40,  h:34},
    {layer:'front', kind:'fern',  x:-10, y:396, w:80,  h:72},
    {layer:'front', kind:'grass', x:270, y:436, w:60,  h:28},
    {layer:'front', kind:'grass', x:560, y:436, w:50,  h:28},
  ],
});

// --- セリフ ----------------------------------------------------------------
const APPEAR=[
  {s:'',c:'narr',t:'茂みが、がさりと揺れた。――狼が、道の上に現れた。'},
  {s:'赤ずきん',c:'hood',t:'あ、狼さん！'},
  {s:'',c:'narr',t:'赤ずきんが、うれしそうに駆け寄っていく。狼の目は、赤ずきんのかごに向いていた。'},
  {s:'',c:'narr',t:'（狼に話しかけよう。……そのまえに、まわりをよく見ておくのもいい）'},
];
const CLUES=[
  { key:'prints', lines:[
    {s:'',c:'narr',t:'道の上に、大きな獣の足あと。爪の先が、深く土に食いこんでいる。'},
    {s:'',c:'narr',t:'足あとは、村のほうから来て……また、村のほうへ向きを変えていた。'} ]},
  { key:'claws', lines:[
    {s:'',c:'narr',t:'木の幹に、大きな爪あと。皮がめくれて、まだ白い。'},
    {s:'',c:'narr',t:'……つい、さっきつけられたものだ。'} ]},
  { key:'shadow', lines:[
    {s:'',c:'narr',t:'低い日が、長い影をのばしている。赤ずきんの影も、少年の影も、ふつうの形だ。'},
    {s:'',c:'narr',t:'……狼の影だけが、大きく口を開けていた。'} ]},
];
const clueCount=()=>CLUES.filter(c=>st.found[c.key]).length;

// --- シーン ----------------------------------------------------------------
GT.registerScene({
  id:'wolf_talk', type:'story', stage:'wolf_talk', label:'第一話 ── 狼',
  intro:[
    {s:'',c:'narr',t:'森の奥へ進むほど、木々は高く、暗くなっていく。',act:'wolf-setup'},
    {s:'赤ずきん',c:'hood',t:'……なんだか、静かすぎるね。'},
  ],
  npcs:[
    { who:'hood', name:'赤ずきん', page:'right', x:560 },   // その場にいる（会話相手は狼）。位置は update で動かす
    { who:'wolf', name:'狼', page:'right', x:WOLF_STAND, lines:[
      {s:'狼',c:'wolf',t:'こんにちは、赤ずきんちゃん。'},
      {s:'赤ずきん',c:'hood',t:'こんにちは。'},
      {s:'狼',c:'wolf',t:'どこへ行くんだい？'},
      {s:'赤ずきん',c:'hood',t:'おばあちゃんのところ。ガレットとバターの壺を届けに。'},
      {s:'狼',c:'wolf',t:'おばあさんは、どこに住んでいるの？'},
      {s:'赤ずきん',c:'hood',t:'この先の、風車小屋を過ぎた、村で一番端のお家よ。'},
      {s:'狼',c:'wolf',t:'僕もそっちへ行くところなんだ。君はその道を、僕はあっちの道を。どっちが早いか競争しよう。'},
      {s:'',c:'narr',t:'狼は、少年の視線を避けるようにして、脇道へ入っていく。',act:'wolf-leave'},
      {s:'',c:'narr',t:'少年は強い違和感を覚えた。赤ずきんに、伝えるべきか。'},
    ], choices:[
      { label:'狼はあやしい、と赤ずきんに伝える', set:()=>{GT.flags.warnedHood=true;}, after:()=>{
        const n=clueCount();
        if(n>=2) return [
          {s:'',c:'narr',t:'少年は、見てきたものを話した。'+[st.found.prints&&'大きな足あと',st.found.claws&&'木の爪あと',st.found.shadow&&'それから――狼の影'].filter(Boolean).join('、')+'。'},
          {s:'赤ずきん',c:'hood',t:'……影？'},
          {s:'',c:'narr',t:'赤ずきんが、狼の消えた脇道をふり返る。かごを抱く手に、力がこもった。'},
          {s:'赤ずきん',c:'hood',t:'……分かった。急ぎましょう。おばあちゃんのところへ。'},
        ];
        return [
          ...(n===1?[{s:'',c:'narr',t:'少年は、見つけたものを話そうとした。けれど、うまく言葉にならない。'}]:[]),
          {s:'赤ずきん',c:'hood',t:'……ただの競争よ？　狼さん、いつも優しいもの。'},
          {s:'',c:'narr',t:'少年がなおも訴える。'},
          {s:'赤ずきん',c:'hood',t:'……分かった。じゃあ、急ぎましょう。'},
        ];
      }},
      { label:'何も言わない', set:()=>{GT.flags.warnedHood=false;}, after:()=>[
        {s:'',c:'narr',t:'少年は口をつぐんだ。赤ずきんは、鼻歌まじりに歩いていく。'},
        ...(clueCount()>0?[{s:'',c:'narr',t:'少年が見たものは、だれにも話されないまま、胸の奥に残った。'}]:[]),
      ]},
    ], onEnd:()=>{ st.phase='done'; GT.fillPage('wolf', GT.flags.warnedHood
        ?'——少年は違和感に気づき、赤ずきんに危険を告げた。'
        :'——狼は、脇道へ消えていった。'); } },
  ],
});

/* ==========================================================================
   進行
   phase: 'walk'（赤ずきんとついてくる）→ 'appear'（狼が出てくる）→ 'wolf'（狼がいる）→ 'done'
   ========================================================================== */
const st={ phase:'walk', busy:false, found:{}, appearT0:0, leaveT0:0, last:performance.now() };
const isWolf=()=>GT.scene&&GT.scene.id==='wolf_talk';
const npc=who=>GT.getNpcs().find(n=>n.who===who);
GT.registerSceneReset(()=>{ if(!isWolf()) return;
  st.phase='walk'; st.busy=false; st.found={}; st.appearT0=0; st.leaveT0=0; GT.flags.wolfClues=0; });
GT.registerAct('wolf-setup',()=>{ const h=npc('hood'), w=npc('wolf');
  if(h) h.x=EDGE; if(w){ w.x=WOLF_HIDE; w.talkable=false; } });
GT.registerAct('wolf-leave',()=>{ st.leaveT0=performance.now(); });

function autoTalk(lines,after){
  st.busy=true; GT.mode='idle'; GT.player.vx=0;
  GT.beginDialogue(lines,null,()=>{ GT.hideDialogue(); GT.mode='play'; st.busy=false; if(after) after(); });
}

GT.registerUpdate(dt=>{
  if(!isWolf()) return;
  const pl=GT.player, pcx=pl.x+pl.w/2, w=npc('wolf');
  if(w) w.talkable = st.phase==='wolf';
  if(st.busy) return;

  // 狼が現れる
  if(st.phase==='walk' && pcx>SPINE+30){ st.phase='appear'; st.appearT0=performance.now(); GT.mode='idle'; pl.vx=0; return; }

  // 違和感を見つける
  const onFloor = pl.onGround && Math.abs(pl.y+pl.h-FLOOR)<2;
  const spots={
    prints: onFloor && pcx>PRINTS.x+20 && pcx<PRINTS.x+PRINTS.w-20,
    claws:  pl.onGround && Math.abs(pl.y+pl.h-BRANCH.y)<2 && pcx<BRANCH.x+BRANCH.w,
    shadow: st.phase==='wolf' && !st.leaveT0 && onFloor && pcx>WOLF_STAND+80,
  };
  for(const c of CLUES){
    if(!st.found[c.key] && spots[c.key]){ st.found[c.key]=true; GT.flags.wolfClues=clueCount(); autoTalk(c.lines); return; }
  }
});

/* ==========================================================================
   描画
   ========================================================================== */
function ell(x,y,rx,ry,c,rot){ ctx.beginPath(); ctx.ellipse(x,y,rx,ry,rot||0,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); }

/* 狼の登場と退場・赤ずきんの移動（会話中・演出中も動くよう、描画のついでに位置を進める） */
function moveActors(){
  const w=npc('wolf'), h=npc('hood'); if(!w||!h) return;
  const now=performance.now(), dt=Math.min(0.05,(now-st.last)/1000); st.last=now;
  // 赤ずきん：狼が出てきたら狼のそばへ駆け寄る。それ以外は少年のうしろをついてくる（会話中は止まる）
  const toWolf = st.phase==='wolf' || (st.phase==='appear' && now-st.appearT0>1400);
  if(toWolf || (GT.mode==='play' && !st.busy)){
    const pcx=GT.player.x+GT.player.w/2;
    const target = toWolf ? HOOD_BY_WOLF : pcx+(pcx>h.x+16?-42:42)-16;
    const dx=target-h.x; if(Math.abs(dx)>6) h.x+=Math.sign(dx)*Math.min((toWolf?150:220)*dt,Math.abs(dx));
    h.x=Math.max(EDGE,Math.min(W-EDGE-32,h.x));
  }
  if(st.phase==='appear'){
    const k=(now-st.appearT0)/1000;
    w.x = WOLF_HIDE-(WOLF_HIDE-WOLF_STAND)*Math.min(1,Math.max(0,(k-0.9)/0.9));
    if(k>2.0){ st.phase='wolf'; GT.mode='play'; autoTalk(APPEAR); }
  }
  if(st.leaveT0){ w.x = WOLF_STAND+Math.max(0,(now-st.leaveT0)/1000-0.3)*80; if(w.x>W+80) w.x=W+80; }
}

/* 暗い森（地形より奥） */
function drawBack(){
  const t=performance.now()/1000;
  ctx.save();
  ctx.fillStyle='rgba(30,26,22,0.13)'; ctx.fillRect(0,0,W,H);
  const vg=ctx.createRadialGradient(W/2,H*0.55,H*0.2,W/2,H*0.55,H);
  vg.addColorStop(0,'rgba(20,16,12,0)'); vg.addColorStop(1,'rgba(20,16,12,0.35)');
  ctx.fillStyle=vg; ctx.fillRect(0,0,W,H);
  // 爪あとの木
  const tr=TRUNK, g=ctx.createLinearGradient(tr.x,0,tr.x+tr.w,0);
  g.addColorStop(0,'#3e3223'); g.addColorStop(0.5,'#55452f'); g.addColorStop(1,'#33291d');
  ctx.fillStyle=g; ctx.fillRect(tr.x,tr.top,tr.w,FLOOR-tr.top);
  [[tr.x+tr.w/2,tr.top,60,'#3f4a35'],[tr.x-30,tr.top+30,44,'#4a573e'],[tr.x+tr.w+30,tr.top+24,46,'#4a573e']]
    .forEach(([x,y,r,c])=>{ ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); });
  ctx.strokeStyle='#e8dcc0'; ctx.lineWidth=2.4; ctx.lineCap='round';
  for(let i=0;i<3;i++){ const x=tr.x+10+i*9; ctx.beginPath(); ctx.moveTo(x,300); ctx.quadraticCurveTo(x+4,322,x+2,348); ctx.stroke(); }
  // 足あと（大きな獣の）
  for(let i=0;i<4;i++){ const x=PRINTS.x+12+i*24, y=FLOOR-3+(i%2)*1;
    ell(x,y,6,2.4,'rgba(40,32,24,0.55)');
    for(let k=-1;k<=1;k++) ell(x+5+k*4,y-3,1.6,1.2,'rgba(40,32,24,0.55)'); }
  // 右ページ奥：狼が消えていく脇道（暗いすきま）
  const pg=ctx.createLinearGradient(0,300,0,FLOOR);
  pg.addColorStop(0,'rgba(20,16,12,0)'); pg.addColorStop(1,'rgba(20,16,12,0.35)');
  ctx.fillStyle=pg; ctx.beginPath(); ctx.moveTo(820,FLOOR); ctx.lineTo(850,300); ctx.lineTo(884,300); ctx.lineTo(884,FLOOR); ctx.closePath(); ctx.fill();
  // 影（低い日が左から当たる：影は右へのびる）
  drawShadows(t);
  ctx.restore();
}
function drawShadows(t){
  const pl=GT.player, h=npc('hood'), w=npc('wolf');
  const plain=(x,len)=>ell(x+len/2,FLOOR-1,len/2,3,'rgba(20,16,12,0.28)');
  if(GT.gravity[GT.currentPage()]===1 && Math.abs(pl.y+pl.h-FLOOR)<4) plain(pl.x+pl.w/2,60);
  if(h && h.x>-100) plain(h.x+16,70);
  if(w && w.x<W && w.x<WOLF_HIDE-20){
    // 狼の影だけ、大きく口を開けた獣の形
    const x=w.x+30, y=FLOOR-1;
    ctx.save(); ctx.fillStyle='rgba(20,12,10,0.6)';
    ctx.beginPath(); ctx.ellipse(x+40,y,46,5,0,0,Math.PI*2); ctx.fill();
    const open=0.35+0.15*Math.sin(t*2);
    ctx.beginPath(); ctx.moveTo(x+80,y-2); ctx.lineTo(x+128,y-16-open*20); ctx.lineTo(x+118,y-4); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x+80,y+1); ctx.lineTo(x+126,y+6+open*10); ctx.lineTo(x+116,y+1); ctx.closePath(); ctx.fill();
    ctx.fillStyle='rgba(232,220,192,0.6)';
    for(let i=0;i<3;i++){ const tx=x+96+i*8; ctx.beginPath(); ctx.moveTo(tx,y-6-i*3-open*8*(i/2)); ctx.lineTo(tx+3,y-1); ctx.lineTo(tx+6,y-6-i*3-open*8*(i/2)); ctx.fill(); }
    ctx.restore();
  }
}

/* 狼が隠れている茂み（狼より手前）と、地面をはう霧 */
function drawFront(){
  const t=performance.now()/1000, pl=GT.player;
  moveActors();
  // 茂み（少年が近づくと揺れる。奥で目が光る）
  const near = st.phase==='walk' && pl.x>280;
  const shake = (st.phase==='appear' ? 4 : near ? 1.6 : 0)*Math.sin(t*28);
  if(st.phase==='walk' && Math.sin(t*1.3)>0.6){
    ell(BUSH.x+60,FLOOR-30,2.6,1.8,'#c9503f'); ell(BUSH.x+74,FLOOR-30,2.6,1.8,'#c9503f'); }
  ctx.save(); ctx.translate(shake,0);
  [[BUSH.x+30,FLOOR-24,34,26,'#2f3a28'],[BUSH.x+75,FLOOR-34,42,34,'#36432e'],[BUSH.x+112,FLOOR-22,30,24,'#2f3a28'],[BUSH.x+60,FLOOR-14,52,16,'#3a4732']]
    .forEach(([x,y,rx,ry,c])=>ell(x,y,rx,ry,c));
  ctx.restore();
  // 霧
  ctx.save();
  for(let i=0;i<5;i++){ const x=((t*(10+i*3)+i*240)%(W+300))-150;
    ell(x,FLOOR-10-(i%3)*10,140,12,'rgba(220,214,200,0.10)'); }
  ctx.restore();
}

/* 違和感の数（上）・違和感のありか（？） */
function drawHud(){
  const t=performance.now()/1000, n=clueCount();
  ctx.save();
  if(st.phase!=='walk' || n>0){
    ctx.font="700 14px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.textBaseline='middle';
    const txt='違和感　'+CLUES.map(c=>st.found[c.key]?'●':'○').join(' ');
    const w=ctx.measureText(txt).width+28;
    GT.roundRect(W/2-w/2,35,w,26,13); ctx.fillStyle='rgba(43,36,24,0.78)'; ctx.fill();
    ctx.fillStyle='#f3ead0'; ctx.fillText(txt,W/2,49);
  }
  // まだ見ていない違和感のありかに、うっすら「？」
  const mark=(x,y)=>{ ctx.globalAlpha=0.6+0.35*Math.sin(t*3+x); ctx.fillStyle='#a8463a';
    ctx.font="700 22px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.fillText('？',x,y); ctx.globalAlpha=1; };
  if(!st.found.prints) mark(PRINTS.x+PRINTS.w/2,FLOOR-24);
  if(!st.found.claws)  mark(TRUNK.x+TRUNK.w/2,290);
  if(!st.found.shadow && st.phase==='wolf' && !st.leaveT0) mark(WOLF_STAND+140,FLOOR-30);
  ctx.restore();
}

GT.registerDraw(()=>{ if(!isWolf()) return; drawBack(); }, 'back');
GT.registerDraw(()=>{ if(!isWolf()) return; drawFront(); drawHud(); }, 'world');
})();
