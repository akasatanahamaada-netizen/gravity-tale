/* ============================================================================
   ステージ：第一話 ── おばあさんの家（結末）  id = 'arrive' / 'ending'
   種類：talk(到着) → boss or qte(injectで差し込み) → end(結末)
   担当：
   ----------------------------------------------------------------------------
   このファイルは、この話の「特別な仕掛け」をまとめて持っています：
     ・狼とのボス戦（spawnWolf / updateWolf / 箱で攻撃。狼のページを裏返すと目を回す）
     ・おばあさんの家の中の背景・家具の見た目・ボス戦の体力バーや演出
     ・QTE（1.6秒以内に本を裏返す）
     ・到着シーン arriveHouse（家の中に入ったところ。分岐で boss か qte を差し込む）
       ※家の前の場面（戸を叩く・赤ずきんを止めるか）は 11_house_front.js
     ・結末 result（flags.route / flags.saved から3つのエンディングを決める。
       戦いのあとの会話 → 夜明けにマリと話す → エンディングの画面 → 本を開く／はじめから）

   ふつうのステージ作りでは、ここまで触る必要はありません。
   新しいボスや仕掛けを足したい人は、ここを参考にしてください。
   仕組み：GT.registerSceneType / registerDynamic / registerUpdate /
          registerDraw / registerModeUpdate / registerFlipIntercept
   ========================================================================== */
(function(){
const ctx=GT.ctx, W=GT.W, H=GT.H, EDGE=GT.EDGE, SPINE=GT.SPINE;

// ボス戦では mode='boss' のあいだ、物理と反転を有効にする
GT.physicsModes.add('boss');
GT.flipModes.add('boss');

// --- おばあさんの家の地形（到着/QTE/ボス戦で共通して使う） ----------------
GT.defineStage('wolf_boss', {
  label:'第一話 ── おばあさんの家',
  platforms:[
    {page:'left', x:120, y:340, w:120, h:20, kind:'ledge'},          // 棚
    {page:'left', x:250, y:90,  w:170, h:20, kind:'ceilingLedge'},   // 梁
    {page:'right',x:520, y:300, w:120, h:20, kind:'ledge'},          // 棚
    {page:'right',x:700, y:150, w:130, h:20, kind:'ledge'},          // 高い棚
    {page:'right',x:560, y:90,  w:150, h:20, kind:'ceilingLedge'},   // 梁
  ],
  // 落として狼に当てる家具（見た目は FURNITURE の順：タンス・つぼ・本の山）
  boxes:[{x:300,y:H-EDGE-34,w:34,h:34},{x:640,y:H-EDGE-34,w:34,h:34},{x:760,y:150-34,w:34,h:34}],
  enemies:[],
});

/* ========================== 狼（ボス） ==================================
   ◆ 攻略のしかた
     ・狼は家具（箱）をすり抜けて歩く。狼が家具と重なったときに、そのページを裏返すと――
       狼は一瞬（GRIP 秒）床にしがみつき（！？）、家具だけが天井へ飛んでいく。
       しがみついているあいだに（少年が着地してから）もう一度裏返すと、家具が戻ってきて狼の頭に落ちる（ダメージ）。
     ・しがみつく時間が過ぎると、狼は天井（床）に打ちつけられて目を回す（DIZZY 秒）。
       目を回しているあいだは、ぶつかっても平気。
     ・家具が当たるのは、狼の「上」（重力の向きで見て）から落ちてきたときだけ。
     ・狼は身構えて（！）から飛びかかる。体力が残り1になると、遠吠えして速くなる。
   ======================================================================= */
const DIZZY=1.8;                       // 目を回している時間(秒)
const GRIP=1.4;                        // 裏返されたとき、床にしがみつく時間(秒)。空中では裏返せないので、少年が着地してから裏返し直せる長さにしてある
const DIZZY_SPEED=900;                 // これより速く打ちつけられると目を回す
let wolf=null;
GT.getBoss=()=>wolf;   // 現在の狼を取り出す（デバッグ・動作確認用）
const fx={ pops:[], stars:[], banner:null, hintOff:false, last:performance.now() };   // 演出
function spawnWolf(advantaged){
  wolf={ x:SPINE+120, y:H-EDGE-52, w:44, h:36, dir:-1,
    hp:advantaged?2:3, maxhp:3, vy:0, vx:0, onGround:false, page:'right',
    stun:0, dizzy:0, windup:0, howl:0, grip:0, lastG:1, enraged:false,
    hitFlash:0, alive:true, deathT:0, squash:1, lungeCD:1.4 };
  fx.pops=[]; fx.stars=[]; fx.banner=null; fx.hintOff=false;
}
function pop(text,x,y,color){ fx.pops.push({text,x,y,color:color||'#c9503f',t:0}); }
function burst(x,y,n){ for(let i=0;i<(n||10);i++){ const a=Math.random()*Math.PI*2, s=120+Math.random()*160;
  fx.stars.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,t:0}); } }

function damageWolf(source){
  if(!wolf||!wolf.alive) return;
  wolf.hp-=1; wolf.hitFlash=1; wolf.stun=0.7; wolf.dizzy=0; wolf.windup=0; wolf.squash=0.6;
  wolf.dir=(source&&source.x<wolf.x)?1:-1; wolf.vy=-260*GT.gravity[wolf.page];
  fx.hintOff=true; GT.hurtFlash=0.25;
  pop('ギャン！',wolf.x+wolf.w/2,wolf.y-8); burst(wolf.x+wolf.w/2,wolf.y+wolf.h/2,12);
  if(wolf.hp<=0){ defeatWolf(); return; }
  if(wolf.hp===1 && !wolf.enraged){ wolf.enraged=true; wolf.howl=1.1; }   // 追いつめられて遠吠え
}
function defeatWolf(){
  wolf.alive=false; wolf.deathT=0; wolf.squash=0.2;
  const hollow=GT.scene&&GT.scene.hollow;
  fx.banner={ text: hollow?'……':'狼を倒した！', t:0 };
  setTimeout(()=>{ GT.flags.saved = hollow?false:true; GT.mode='idle'; GT.advanceScene(); },1700);
}
// 狼にぶつかられた：はじき飛ばされる（はじめの場所へは戻されない）
function hurtPlayer(){
  const pl=GT.player, g=GT.gravity[GT.currentPage()];
  const away=(pl.x+pl.w/2<wolf.x+wolf.w/2)?-1:1;
  pl.vx=away*420; pl.vy=-380*g; pl.squash=0.6;
  GT.hurtFlash=1; GT.invincible=1.2;
  pop('いたっ',pl.x+pl.w/2,pl.y-6,'#4a4e6d');
}
function updateWolf(dt){
  const gravity=GT.gravity, player=GT.player;
  wolf.hitFlash=Math.max(0,wolf.hitFlash-dt*2.5); wolf.page=GT.pageOf(wolf);
  const wg=gravity[wolf.page];
  if(!wolf.alive){ wolf.deathT+=dt; return; }
  // ページの重力が変わった（裏返された・ページをまたいだ）：立っていれば、しばらくしがみつく
  if(wg!==wolf.lastG){ wolf.lastG=wg;
    if(wolf.onGround && wolf.dizzy<=0){ wolf.grip=GRIP; wolf.windup=0; wolf.vy=0; wolf.vx=0; pop('！？',wolf.x+wolf.w/2,wg===1?wolf.y+wolf.h+24:wolf.y-8,'#5a4630'); } }
  if(wolf.grip>0){ wolf.grip-=dt; wolf.squash+=(0.8-wolf.squash)*Math.min(1,dt*10); return; }
  const speed=GT.ENEMY_SPEED*(wolf.enraged?1.8:1.3);
  if(wolf.howl>0){ wolf.howl-=dt; if(wolf.howl<=0) pop('ウォォォン！',wolf.x+wolf.w/2,wolf.y-10,'#8b3a2f'); }
  else if(wolf.dizzy>0){ wolf.dizzy-=dt; }
  else if(wolf.stun>0){ wolf.stun-=dt; }
  else if(wolf.windup>0){                                   // 身構えている
    wolf.windup-=dt; wolf.squash+=(1.3-wolf.squash)*Math.min(1,dt*12);
    if(wolf.windup<=0 && wolf.onGround){ wolf.vy=-560*wg; wolf.vx=wolf.dir*(wolf.enraged?380:300); }
  }
  else{
    wolf.lungeCD-=dt; const dir=(player.x<wolf.x)?-1:1; wolf.dir=dir;
    wolf.x+=dir*speed*dt;
    if(wolf.lungeCD<=0&&wolf.onGround){ wolf.windup=wolf.enraged?0.32:0.5; wolf.lungeCD=wolf.enraged?1.0:1.6; }
  }
  wolf.vy+=GT.GRAVITY*wg*dt; wolf.x+=(wolf.vx||0)*dt; wolf.vx=(wolf.vx||0)*0.9;
  // 左右の端は、上下の当たり判定より先に止める。
  // （壁にめり込んだまま上下の判定をすると、壁の上・下＝画面の外へ押し出されてしまう）
  if(wolf.x<EDGE){ wolf.x=EDGE; wolf.vx=0; } if(wolf.x+wolf.w>W-EDGE){ wolf.x=W-EDGE-wolf.w; wolf.vx=0; }
  const vyBefore=wolf.vy;
  // 速く落ちても薄い足場をすり抜けないよう、8px ずつ刻んで判定する（壁は上下の判定に使わない）
  wolf.onGround=false;
  const plats=GT.pagePlatforms(wolf.page).filter(p=>p.kind!=='wallEdge');
  const steps=Math.max(1,Math.ceil(Math.abs(wolf.vy*dt)/8));
  for(let i=0;i<steps&&wolf.vy!==0;i++){ wolf.y+=wolf.vy*dt/steps; GT.resolveBodyCollisions(wolf,'y',plats); }
  // 念のため：ページの外に出ていたら、床（天井）へ戻す
  if(wolf.y<EDGE || wolf.y+wolf.h>H-EDGE || !isFinite(wolf.y)){
    wolf.y = wg===1 ? H-EDGE-wolf.h : EDGE; wolf.vy=0; }
  // 天井（床）に勢いよく打ちつけられたら、目を回す
  if(wolf.vy===0 && vyBefore*wg>DIZZY_SPEED){
    wolf.dizzy=DIZZY; wolf.windup=0; wolf.squash=0.5; wolf.vx=0;
    pop('ドスン！',wolf.x+wolf.w/2,wolf.y+wolf.h/2,'#5a4630'); burst(wolf.x+wolf.w/2,wg===1?wolf.y+wolf.h:wolf.y,8);
  }
  wolf.squash+=(1-wolf.squash)*Math.min(1,dt*8);
  if(GT.invincible<=0&&wolf.alive&&wolf.stun<=0&&wolf.dizzy<=0&&wolf.grip<=0&&GT.rectsOverlap(player,wolf)){ hurtPlayer(); }
}

// 毎フレーム：落ちてくる箱が狼に当たればダメージ。そのあと狼を動かす。
GT.registerUpdate(dt=>{
  if(GT.mode!=='boss'||!wolf) return;
  if(wolf.alive){
    const wg=GT.gravity[wolf.page];
    for(const box of GT.boxes){
      // 狼の「上」（重力の向きで見て）から落ちてきた家具だけが当たる
      const fromAbove = wg===1 ? box.y+box.h/2 < wolf.y+wolf.h/2 : box.y+box.h/2 > wolf.y+wolf.h/2;
      if(GT.rectsOverlap(box,wolf)&&fromAbove&&box.vy*wg>140&&wolf.stun<=0){ damageWolf(box); box.vy=-box.vy*0.3; box.squash=1.3; }
    }
  }
  updateWolf(dt);
});

// 狼の描画（プレイヤーより後ろ）
function drawWolf(){
  if(!wolf) return; const wg=GT.gravity[wolf.page], t=performance.now()/1000; ctx.save();
  const sx=wolf.squash, sy=2-wolf.squash; const hw=(wolf.w/2)*sx, hh=(wolf.h/2)*sy;
  const shake = wolf.howl>0 ? Math.sin(t*60)*2 : 0;
  ctx.translate(wolf.x+wolf.w/2+shake,wolf.y+wolf.h/2); ctx.scale(wolf.dir>=0?1:-1,wg);
  if(!wolf.alive){ ctx.globalAlpha=Math.max(0.2,1-wolf.deathT*0.5); ctx.beginPath(); GT.roundRectPath(-hw*1.35,-hh*0.4,hw*2.7,hh*0.8,6); ctx.fillStyle='#3a2f2a'; ctx.fill(); ctx.restore(); return; }
  // しっぽ
  ctx.fillStyle='#3a2f2a'; ctx.beginPath(); ctx.moveTo(-hw+2,-hh*0.4); ctx.quadraticCurveTo(-hw-16,-hh*0.9+Math.sin(t*6)*3,-hw-14,hh*0.2); ctx.lineTo(-hw+2,hh*0.1); ctx.closePath(); ctx.fill();
  ctx.beginPath(); GT.roundRectPath(-hw,-hh,hw*2,hh*2,8); ctx.fillStyle=wolf.hitFlash>0?'#8b3a2f':'#3a2f2a'; ctx.fill();
  ctx.beginPath(); GT.roundRectPath(hw-4,-hh*0.2,hw*0.5,hh*0.5,4); ctx.fillStyle='#2c231f'; ctx.fill();
  // 牙
  ctx.fillStyle='#e8dcc0'; ctx.beginPath(); ctx.moveTo(hw+2,hh*0.28); ctx.lineTo(hw+5,hh*0.55); ctx.lineTo(hw+8,hh*0.28); ctx.fill();
  ctx.fillStyle='#3a2f2a'; ctx.beginPath(); ctx.moveTo(hw-10,-hh); ctx.lineTo(hw-4,-hh-11); ctx.lineTo(hw+2,-hh); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(-hw+2,-hh); ctx.lineTo(-hw+8,-hh-11); ctx.lineTo(-hw+14,-hh); ctx.closePath(); ctx.fill();
  if(wolf.dizzy>0){                                          // 目がぐるぐる
    ctx.strokeStyle='#e8dcc0'; ctx.lineWidth=1.4; ctx.beginPath(); ctx.arc(hw-9,-3,3,t*8,t*8+Math.PI*1.5); ctx.stroke();
  } else {
    if(wolf.enraged){ ctx.shadowColor='rgba(255,60,40,0.9)'; ctx.shadowBlur=8; }
    ctx.fillStyle='#c9503f'; ctx.beginPath(); ctx.arc(hw-9,-3,2.6,0,Math.PI*2); ctx.fill(); ctx.shadowBlur=0;
  }
  ctx.restore();
  // 目を回している星・身構えの「！」
  const cx=wolf.x+wolf.w/2, headY = wg===1 ? wolf.y-10 : wolf.y+wolf.h+10;
  if(wolf.dizzy>0){ ctx.save(); ctx.fillStyle='#e8c35a';
    for(let i=0;i<3;i++){ const a=t*5+i*2.1; star(cx+Math.cos(a)*18, headY+Math.sin(a)*5, 5); ctx.fill(); }
    ctx.restore(); }
  if(wolf.windup>0){ ctx.save(); ctx.font="700 22px 'Zen Old Mincho',serif"; ctx.textAlign='center';
    ctx.fillStyle='#c9503f'; ctx.fillText('！',cx,wg===1?headY-6:headY+22); ctx.restore(); }
}
function star(cx,cy,r){ ctx.beginPath(); for(let i=0;i<10;i++){ const a=-Math.PI/2+i*Math.PI/5, rr=i%2?r*0.45:r; ctx.lineTo(cx+Math.cos(a)*rr,cy+Math.sin(a)*rr); } ctx.closePath(); }
GT.registerDraw(()=>{ if(GT.mode==='boss'||(wolf&&!wolf.alive&&GT.scene&&GT.scene.type==='boss')) drawWolf(); },'world');

/* ---- ボス戦の画面表示：体力バー・攻略のヒント・ポップ文字・勝利の文字 ---- */
function drawBossHud(){
  if(!wolf || !GT.scene || GT.scene.type!=='boss') return;
  const now=performance.now(), dt=Math.min(0.05,(now-fx.last)/1000); fx.last=now;
  ctx.save();
  // 体力バー
  const bw=220, bx=W/2-bw/2, by=34;
  GT.roundRect(bx-10,by-6,bw+20,30,14); ctx.fillStyle='rgba(43,36,24,0.82)'; ctx.fill();
  ctx.font="700 13px 'Zen Old Mincho',serif"; ctx.textBaseline='middle'; ctx.textAlign='left'; ctx.fillStyle='#f3ead0';
  ctx.fillText('狼',bx+2,by+9);
  for(let i=0;i<wolf.maxhp;i++){ const x=bx+30+i*((bw-34)/wolf.maxhp);
    GT.roundRect(x,by+3,(bw-34)/wolf.maxhp-6,12,6); ctx.fillStyle=i<wolf.hp?(wolf.enraged?'#e0563f':'#c9503f'):'rgba(232,220,192,0.18)'; ctx.fill(); }
  // ヒント（はじめて当てるまで）
  if(!fx.hintOff && GT.mode==='boss'){
    ctx.textAlign='center'; ctx.font="700 13px 'Zen Old Mincho',serif";
    GT.roundRect(W/2-210,122,420,48,12); ctx.fillStyle='rgba(43,36,24,0.72)'; ctx.fill();
    ctx.globalAlpha=0.8+0.2*Math.sin(now/300); ctx.fillStyle='#f3ead0';
    ctx.fillText('狼が家具と重なったら そのページを裏返し、着地したら すぐもう一度',W/2,137);
    ctx.fillText('しがみつく狼の頭に、飛んでいった家具が落ちてくる',W/2,157);
    ctx.globalAlpha=1;
  }
  // ポップ文字
  ctx.textAlign='center'; ctx.font="700 18px 'Zen Old Mincho',serif";
  fx.pops=fx.pops.filter(p=>{ p.t+=dt; if(p.t>0.9) return false;
    ctx.globalAlpha=1-p.t/0.9; ctx.fillStyle=p.color; ctx.fillText(p.text,p.x,p.y-p.t*30); return true; });
  // 星の粒
  ctx.fillStyle='#e8c35a';
  fx.stars=fx.stars.filter(s=>{ s.t+=dt; if(s.t>0.6) return false; s.x+=s.vx*dt; s.y+=s.vy*dt;
    ctx.globalAlpha=1-s.t/0.6; star(s.x,s.y,4); ctx.fill(); return true; });
  // 勝利の文字
  if(fx.banner){ fx.banner.t+=dt; const k=fx.banner.t;
    ctx.globalAlpha=Math.min(1,k*3)*(k>1.4?Math.max(0,1-(k-1.4)*3):1);
    ctx.font="700 40px 'Zen Old Mincho',serif"; ctx.fillStyle='rgba(43,36,24,0.85)';
    ctx.fillText(fx.banner.text,W/2+2,H/2-18); ctx.fillStyle='#f3ead0'; ctx.fillText(fx.banner.text,W/2,H/2-20); }
  ctx.restore();
}
GT.registerDraw(drawBossHud,'overlay');

/* ---- おばあさんの家の中（ボス戦・QTE・結末の背景） ------------------------ */
const isRoom=()=>GT.scene&&(GT.scene.type==='boss'||GT.scene.type==='qte'||(GT.scene.type==='end'&&!ending.epilogue));
function ell(x,y,rx,ry,c){ ctx.beginPath(); ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); }
function drawRoom(){
  if(!isRoom()) return;
  const t=performance.now()/1000, FLOOR=H-EDGE, cast=castNow(), dim=!!cast.dim;
  ctx.save();
  // 板張りの壁と床
  ctx.fillStyle=dim?'rgba(40,34,30,0.22)':'rgba(140,96,58,0.16)'; ctx.fillRect(0,0,W,H);
  ctx.strokeStyle='rgba(90,64,40,0.18)'; ctx.lineWidth=1;
  for(let x=0;x<W;x+=36){ ctx.beginPath(); ctx.moveTo(x,EDGE); ctx.lineTo(x,FLOOR-24); ctx.stroke(); }
  ctx.fillStyle='rgba(110,78,48,0.3)'; ctx.fillRect(0,FLOOR-24,W,24);
  // 窓と月
  ctx.fillStyle='#4a3a28'; ctx.fillRect(262,148,84,84);
  ctx.fillStyle='#2b2e4a'; ctx.fillRect(268,154,72,72);
  ell(318,176,12,12,'#e6dcc0'); ell(313,172,12,12,'#2b2e4a');
  ctx.fillStyle='#4a3a28'; ctx.fillRect(302,154,4,72); ctx.fillRect(268,188,72,4);
  // 暖炉（右ページ）
  ctx.fillStyle='#7a6a5a'; ctx.fillRect(770,330,96,FLOOR-330); ctx.fillStyle='#5f5246'; ctx.fillRect(762,322,112,12);
  ctx.fillStyle='#1e1812'; ctx.beginPath(); ctx.moveTo(788,FLOOR); ctx.lineTo(788,380); ctx.arc(818,380,30,Math.PI,0); ctx.lineTo(848,FLOOR); ctx.closePath(); ctx.fill();
  if(!dim){ const fl=1+0.15*Math.sin(t*11);
    const g=ctx.createRadialGradient(818,FLOOR-14,4,818,FLOOR-14,120); g.addColorStop(0,'rgba(255,160,60,0.35)'); g.addColorStop(1,'rgba(255,160,60,0)');
    ctx.fillStyle=g; ctx.fillRect(690,300,210,FLOOR-300);
    ell(818,FLOOR-14,12*fl,18*fl,'#ffb347'); ell(818,FLOOR-10,6*fl,9*fl,'#fff0b0'); }
  // ベッド（左ページ）
  ctx.fillStyle='#6b4f36'; ctx.fillRect(22,392,8,FLOOR-392); ctx.fillRect(146,414,8,FLOOR-414);
  ctx.fillStyle='#e8dcc0'; ctx.fillRect(28,420,122,26);
  ctx.fillStyle=dim?'#8a8070':'#8b5e63'; ctx.fillRect(56,416,96,30);
  ell(44,418,14,7,'#f6eed8');
  drawCast(t,cast);
  ctx.restore();
}
/* 部屋にいる人（分岐・場面で変わる）
   granny: 'shiver'（ベッドで震える）/'sit'（ベッドに腰かける）  hood: 'corner'/'bedside'/'shawl'
   cap: ベッドに残された赤い頭巾  wolfDown: 倒れた狼  dim: 暗い部屋 */
function castNow(){
  const sc=GT.scene||{}, f=GT.flags;
  if(sc.type==='end'){ const k=ending.kind;
    return { granny:k==='true'?'sit':null,
             hood:k==='true'?(ending.hoodIn?'bedside':null):k==='normal'?'shawl':null,
             cap:k==='bad', wolfDown:true, dim:k==='bad' }; }
  if(sc.hollow) return { cap:true, dim:true };
  if(f.route==='shortcut') return { granny:'shiver' };
  return { hood:'corner' };
}
function drawHoodSmall(x,foot,alpha){
  const hw=12, hh=15;
  ctx.save(); ctx.globalAlpha=alpha==null?1:alpha; ctx.translate(x,foot-hh);
  ctx.fillStyle='#2b2e4a'; GT.roundRect(-hw,-hh,hw*2,hh*2,7); ctx.fill();
  ctx.fillStyle='#b8423f'; ctx.beginPath(); ctx.arc(0,-hh,hw*0.95,Math.PI,0); ctx.closePath(); ctx.fill();
  ctx.globalAlpha*=0.92; ctx.beginPath(); ctx.moveTo(-hw,-hh*0.1); ctx.lineTo(hw,-hh*0.1); ctx.lineTo(hw*0.7,hh*0.9); ctx.lineTo(-hw*0.7,hh*0.9); ctx.closePath(); ctx.fill();
  ctx.globalAlpha=alpha==null?1:alpha; ell(-4,-hh*0.35,1.8,1.8,'#e8dcc0'); ell(4,-hh*0.35,1.8,1.8,'#e8dcc0');
  ctx.restore();
}
function drawCast(t,c){
  const FLOOR=H-EDGE, shiver=Math.sin(t*30)*0.8;
  if(c.cap){ ctx.fillStyle='#b8423f'; ctx.beginPath(); ctx.moveTo(70,416); ctx.quadraticCurveTo(92,398,118,416); ctx.lineTo(110,424); ctx.lineTo(78,424); ctx.closePath(); ctx.fill(); }
  if(c.granny){                                     // おばあさん
    const x=96+(c.granny==='shiver'?shiver:0), y=402;
    ctx.fillStyle='#8a7fa0'; GT.roundRect(x-12,y-6,24,26,8); ctx.fill();
    ell(x,y-12,9,9,'#ecd0a8'); ell(x,y-18,11,6,'#f6eed8');
    ell(x-3,y-12,1.3,1.3,'#2b2e4a'); ell(x+3,y-12,1.3,1.3,'#2b2e4a');
  }
  if(c.hood==='corner') drawHoodSmall(196+shiver,FLOOR);
  if(c.hood==='bedside') drawHoodSmall(176,FLOOR,Math.min(1,(performance.now()-ending.hoodInT)/600));
  if(c.hood==='shawl'){ drawHoodSmall(176,FLOOR);   // おばあさんの肩掛けを抱いている
    ctx.fillStyle='#8a7fa0'; ctx.beginPath(); ctx.ellipse(186,FLOOR-14,10,7,0.3,0,Math.PI*2); ctx.fill(); }
  if(c.wolfDown){                                   // 倒れた狼
    ell(640,FLOOR-7,30,8,'#3a2f2a'); ctx.fillStyle='#3a2f2a';
    ctx.beginPath(); ctx.moveTo(662,FLOOR-12); ctx.lineTo(670,FLOOR-22); ctx.lineTo(674,FLOOR-10); ctx.fill(); }
}
GT.registerDraw(drawRoom,'back');

/* 落とす箱を、家具の見た目にする（タンス・つぼ・本の山） */
const FURNITURE=['chest','pot','books'];
function drawFurniture(){
  if(!isRoom()) return;
  GT.boxes.forEach((b,i)=>{
    const kind=FURNITURE[i%FURNITURE.length], sx=b.squash, sy=2-b.squash;
    const w=b.w*sx, h=b.h*sy, x=b.x+b.w/2-w/2, y=b.y+b.h/2-h/2;
    ctx.save();
    if(kind==='chest'){
      GT.roundRect(x,y,w,h,4); ctx.fillStyle='#7a5434'; ctx.fill();
      ctx.fillStyle='#5a3f2e'; ctx.fillRect(x+2,y+h*0.33,w-4,2); ctx.fillRect(x+2,y+h*0.66,w-4,2);
      ell(x+w/2,y+h*0.18,2.2,2.2,'#d9b877'); ell(x+w/2,y+h*0.5,2.2,2.2,'#d9b877'); ell(x+w/2,y+h*0.83,2.2,2.2,'#d9b877');
    } else if(kind==='pot'){
      ctx.fillStyle='#b0704a'; ctx.beginPath(); ctx.ellipse(x+w/2,y+h*0.58,w*0.48,h*0.42,0,0,Math.PI*2); ctx.fill();
      ctx.fillRect(x+w*0.28,y+h*0.06,w*0.44,h*0.2); ctx.fillStyle='#8b5236'; ctx.fillRect(x+w*0.22,y+h*0.02,w*0.56,h*0.08);
      ctx.fillStyle='rgba(255,240,210,0.35)'; ctx.fillRect(x+w*0.2,y+h*0.5,w*0.6,2);
    } else {
      ['#57644a','#8b5e63','#b08d57','#4a4e6d'].forEach((c,k)=>{ const bh=h/4;
        ctx.fillStyle=c; ctx.fillRect(x+(k%2?2:0),y+k*bh,w-2,bh-1);
        ctx.fillStyle='rgba(232,220,192,0.5)'; ctx.fillRect(x+(k%2?4:2),y+k*bh+bh/2-1,w-8,1.5); });
    }
    ctx.restore();
  });
}
GT.registerDraw(drawFurniture,'world');

// ボス戦シーン（injectSceneAfterCurrent で差し込まれる {type:'boss',...}）
GT.registerSceneType('boss', scene=>{
  GT.loadStageDef(GT.STAGE_DEFS['wolf_boss']); spawnWolf(scene.advantaged); GT.mode='idle';
  if(scene.advantaged){ wolf.dizzy=DIZZY; }        // 先手を取った：狼は不意をつかれて目を回している
  GT.setHudStage('第一話 ── 狼との戦い');
  GT.beginDialogue(scene.intro||[],null,()=>{ GT.hideDialogue(); GT.mode='boss'; });
});

/* ============================ QTE ====================================== */
let qteActive=false, qteTimer=0, qteWindow=0;

GT.registerSceneType('qte', ()=>{
  GT.loadStageDef(GT.STAGE_DEFS['wolf_boss']); GT.mode='idle'; qteActive=false;
  GT.setHudStage('第一話 ── ！');
  const lines=[
    {s:'狼',c:'wolf',t:'（おばあさんの声で）ガレットとバターの壺は戸棚に。そして、わたしのそばにおいで。'},
    {s:'赤ずきん',c:'hood',t:'まあ、おばあちゃん、なんて大きな腕なの。'},
    {s:'狼',c:'wolf',t:'おまえをよく抱きしめるためだよ。'},
    {s:'赤ずきん',c:'hood',t:'なんて大きな耳なの。'},
    {s:'狼',c:'wolf',t:'よく聞こえるようにだよ。'},
    {s:'赤ずきん',c:'hood',t:'なんて大きな目なの。'},
    {s:'狼',c:'wolf',t:'よく見えるようにだよ。'},
    {s:'赤ずきん',c:'hood',t:'なんて大きな歯なの。'},
    {s:'狼',c:'wolf',t:'……おまえを食べるためだよ！'},
  ];
  GT.beginDialogue(lines,null,()=>{
    GT.hideDialogue(); qteActive=true;
    qteWindow=1.6; qteTimer=0; GT.mode='qte';
    document.getElementById('qte').classList.add('show');
    document.getElementById('qteBig').textContent='狼が跳ねた！';
  });
});
// QTE 中の時間切れ判定
GT.registerModeUpdate('qte', dt=>{ if(!qteActive) return; qteTimer+=dt; if(qteTimer>=qteWindow){ resolveQTE(false); } });
// QTE 中は、反転キー＝成功
GT.registerFlipIntercept(()=>{ if(qteActive){ resolveQTE(true); return true; } return false; });
// QTEボタン
document.getElementById('qteBtn').addEventListener('pointerdown',e=>{ e.preventDefault(); if(qteActive) resolveQTE(true); });

function resolveQTE(success){
  if(!qteActive) return; qteActive=false;
  document.getElementById('qte').classList.remove('show');
  if(success){
    GT.beginDialogue([
      {s:'',c:'narr',t:'間に合った。少年は本を裏返し、狼の軌道を逸らして赤ずきんを引き離した。'},
    ], null, ()=>{
      GT.injectSceneAfterCurrent({type:'boss',advantaged:false,intro:[
        {s:'',c:'narr',t:'狼が牙をむく。本を裏返し、家具を落として反撃しろ。'} ]});
      GT.advanceScene();
    });
  } else {
    GT.flags.saved=false;
    GT.beginDialogue([
      {s:'',c:'narr',t:'――間に合わなかった。'},
      {s:'',c:'narr',t:'画面が暗転する。音が、止む。'},
    ], null, ()=>{
      GT.injectSceneAfterCurrent({type:'boss',advantaged:false,hollow:true,intro:[
        {s:'',c:'narr',t:'明るくなると、部屋には誰もいない。ベッドに、赤い頭巾だけが残されていた。'} ]});
      GT.advanceScene();
    });
  }
}

/* ========================= 到着（分岐の要） =============================
   家の前の場面は 11_house_front.js（戸を叩く・赤ずきんを止めるかの選択はそちら）。
   ここは、戸を開けて中に入ったところ。flags.route / flags.stoppedAtDoor で分かれる。 */
GT.registerDynamic('arriveHouse', ()=>{
  GT.loadStageDef(GT.STAGE_DEFS['wolf_boss']); GT.mode='idle';
  GT.setHudStage('第一話 ── おばあさんの家');
  if(GT.flags.route==='shortcut'){
    GT.beginDialogue([
      {s:'',c:'narr',t:'少年は戸を押し開けた。――寝間着姿の狼が、まさに牙をむこうとしていた。'},
      {s:'おばあさん',c:'granny',t:'ひ……！　だ、誰か……！'},
      {s:'',c:'narr',t:'狼が、こちらを振り向く。間に合った。'},
    ], null, ()=>{
      GT.injectSceneAfterCurrent({type:'boss',advantaged:true,intro:[
        {s:'',c:'narr',t:'本を裏返し、天井から家具を落として狼を追い詰めろ。'} ]});
      GT.advanceScene();
    });
    return;
  }
  if(GT.flags.stoppedAtDoor){
    GT.beginDialogue([
      {s:'',c:'narr',t:'少年が先に、そっと中をうかがう。ベッドに、寝間着の狼が横たわっていた。'},
      {s:'',c:'narr',t:'赤ずきんが、戸口で息をのむ。……奇襲できる。'},
    ], null, ()=>{
      GT.injectSceneAfterCurrent({type:'boss',advantaged:true,intro:[
        {s:'',c:'narr',t:'眠ったふりの狼へ、先に踏み込め。本を裏返し、家具を落とせ。'} ]});
      GT.advanceScene();
    });
    return;
  }
  GT.beginDialogue([
    {s:'',c:'narr',t:'部屋は薄暗い。ベッドのカーテンの向こうに、おばあさんが寝ている。'},
    {s:'',c:'narr',t:'赤ずきんが、ベッドのそばへ歩いていく。……何かが、おかしい。'},
  ], null, ()=>{ GT.injectSceneAfterCurrent({type:'qte'}); GT.advanceScene(); });
});

/* ============================ 結末 =====================================
   戦いのあとの場面 → 外に出て、夜明けにマリと話す → エンディングの画面
   エンディングは3つ：
     true   … 近道で先回りし、二人とも助けた            「ふたりとも、間に合った」
     normal … 遠回り。赤ずきんは助けたが、おばあさんは…  「ひとりだけの朝」
     bad    … QTE に失敗し、だれも助けられなかった      「赤い頭巾だけが」
   ======================================================================= */
const ENDINGS={
  true:  { mark:'A', title:'ふたりとも、間に合った' },
  normal:{ mark:'B', title:'ひとりだけの朝' },
  bad:   { mark:'C', title:'赤い頭巾だけが' },
};
const ending={ kind:'true', hoodIn:false, hoodInT:0, epilogue:false, card:false, cardT:0 };
GT.defineStage('ending_room', { label:'第一話 ── おばあさんの家', platforms:[], boxes:[], enemies:[] });
GT.registerAct('end-hood-in', ()=>{ ending.hoodIn=true; ending.hoodInT=performance.now(); });
GT.registerAct('end-epilogue',()=>{ ending.epilogue=true; GT.setHudStage('第一話 ── 夜明け'); });
GT.registerAct('end-card',    ()=>{ ending.card=true; ending.cardT=performance.now(); GT.setHudStage('第一話・完'); });

const AFTER={
  true:[
    {s:'おばあさん',c:'granny',t:'ああ、助かった……。あんた、いったい何者だい。'},
    {s:'',c:'narr',t:'少年は答えられない。手の中で、本がかすかに震えている。'},
    {s:'おばあさん',c:'granny',t:'その本……ふしぎだねえ。さっき、部屋がまるごとひっくり返ったように見えたよ。'},
    {s:'',c:'narr',t:'戸口で、ぱたぱたと足音がした。',act:'end-hood-in'},
    {s:'赤ずきん',c:'hood',t:'おばあちゃん！　……あ、あなたも。もしかして、助けてくれたの？'},
    {s:'',c:'narr',t:'少年は何も言わない。ただ、頷く。'},
    {s:'赤ずきん',c:'hood',t:'もう……近道するなら、そう言ってよ。わたし、ひとりで歩いてきたんだから。'},
    {s:'おばあさん',c:'granny',t:'まあまあ。……おや、それはガレットかい。'},
    {s:'赤ずきん',c:'hood',t:'うん！　バターの壺も。……ちょっと、揺れちゃったけど。'},
    {s:'',c:'narr',t:'三人で、ガレットを分けあった。暖炉の火が、ぱちぱちと鳴っている。'},
    {s:'赤ずきん',c:'hood',t:'……森って、本当は怖いところなのね。'},
    {s:'赤ずきん',c:'hood',t:'でも、今日はあなたがいてくれた。……ありがとう。'},
    {s:'',c:'narr',t:'——少年は、間に合った。赤頭巾も、おばあさんも、無事だった。'},
  ],
  normal:[
    {s:'赤ずきん',c:'hood',t:'……ありがとう。あなたが来てなかったら、わたし……'},
    {s:'',c:'narr',t:'少年は何も言わない。ただ、頷く。'},
    {s:'',c:'narr',t:'赤ずきんが、空っぽのベッドを見つめる。'},
    {s:'赤ずきん',c:'hood',t:'……おばあちゃんは？　ねえ、おばあちゃんは、どこ……？'},
    {s:'',c:'narr',t:'ベッドのそばに、おばあさんの肩掛けが落ちていた。まだ、少しだけ温かい。'},
    {s:'赤ずきん',c:'hood',t:'……遠回りなんて、しなければよかった。'},
    {s:'',c:'narr',t:'少年は、答えられなかった。'},
    {s:'赤ずきん',c:'hood',t:'……ううん。あなたのせいじゃない。わたしが、狼さんに、お家の場所を教えたから。'},
    {s:'',c:'narr',t:'赤ずきんは、肩掛けを胸に抱いた。暖炉の火だけが、変わらずに燃えている。'},
    {s:'',c:'narr',t:'——少年は、赤頭巾だけを、間に合わせた。'},
  ],
  bad:[
    {s:'',c:'narr',t:'狼は倒れた。だが、部屋には、もう誰もいない。'},
    {s:'',c:'narr',t:'ベッドの上の赤い頭巾だけが、静かにそこにあった。'},
    {s:'',c:'narr',t:'少年は、頭巾を手に取った。床に落ちたかごの中で、ガレットはまだ温かかった。'},
    {s:'',c:'narr',t:'——少年は、間に合わなかった。'},
  ],
};
const EPILOGUE={
  true:[
    {s:'',c:'narr',t:'手の中の本が、熱を帯びる。白いページに、文字がひとりでに書かれていく。'},
    {s:'',c:'narr',t:'……気がつくと、少年は家の外にいた。夜が、明けはじめている。',act:'end-epilogue'},
    {s:'マリ',c:'mari',t:'おかえり。'},
    {s:'マリ',c:'mari',t:'……うん。ちゃんと見て、ちゃんと話したね。'},
    {s:'マリ',c:'mari',t:'ほら。一話ぶん、埋まった。'},
    {s:'',c:'narr',t:'少年が本を開く。虫食いだったページが、文字と絵で埋まっていた。'},
    {s:'マリ',c:'mari',t:'でも、本はまだずっと続いてる。……次のお話も、白いままだよ。'},
    {s:'マリ',c:'mari',t:'また、一緒に行こう。'},
  ],
  normal:[
    {s:'',c:'narr',t:'手の中の本が、熱を帯びる。白いページに、文字がひとりでに書かれていく。'},
    {s:'',c:'narr',t:'……気がつくと、少年は家の外にいた。夜が、明けはじめている。',act:'end-epilogue'},
    {s:'マリ',c:'mari',t:'おかえり。'},
    {s:'マリ',c:'mari',t:'……そっか。ひとりは、間に合わなかったんだね。'},
    {s:'マリ',c:'mari',t:'ページは埋まったよ。……こういうお話として。'},
    {s:'',c:'narr',t:'少年が本を開く。最後のページの文字だけが、少しにじんでいた。'},
    {s:'マリ',c:'mari',t:'本はね、書き直せないの。でも――もう一度、最初から読むことはできる。'},
    {s:'マリ',c:'mari',t:'……どこで、どの道を選べばよかったんだろうね。'},
  ],
  bad:[
    {s:'',c:'narr',t:'手の中の本が、冷たく重い。白いページに、文字がひとりでに書かれていく。'},
    {s:'',c:'narr',t:'……気がつくと、少年は家の外にいた。夜が、明けようとしていた。',act:'end-epilogue'},
    {s:'マリ',c:'mari',t:'……おかえり。'},
    {s:'マリ',c:'mari',t:'……つらかったね。'},
    {s:'マリ',c:'mari',t:'ページは、それでも埋まるの。このお話は、こういうお話になった。'},
    {s:'マリ',c:'mari',t:'でも、あなたはもう知ってる。どこで、手を伸ばせばよかったか。'},
    {s:'マリ',c:'mari',t:'……もう一度、最初から読む？'},
  ],
};

GT.registerDynamic('result', ()=>{
  GT.loadStageDef(GT.STAGE_DEFS['ending_room']); GT.mode='idle';
  GT.player.x=430; GT.player.y=H-EDGE-GT.player.h; GT.player.facing=-1;
  GT.setHudStage('第一話 ── おばあさんの家');
  const flags=GT.flags;
  const hoodSaved = flags.saved!==false;
  const grannySaved = (flags.route==='shortcut') && hoodSaved;   // おばあさんが助かるのは近道のときだけ
  flags.grannyAlive = grannySaved;
  Object.assign(ending,{ kind: grannySaved?'true':hoodSaved?'normal':'bad', hoodIn:false, hoodInT:0, epilogue:false, card:false, cardT:0 });
  flags.ending=ending.kind;

  GT.fillPage('granny', grannySaved
    ? '——おばあさんは無事だった。少年が、狼より先に家へ着いたから。'
    : (flags.route==='shortcut'
        ? '——おばあさんを救えなかった。'
        : '——家に着いたとき、おばあさんはすでに狼の腹の中だった。'));
  const hoodLine = hoodSaved ? '赤ずきん：救えた' : '赤ずきん：救えなかった';
  const grannyLine = grannySaved ? 'おばあさん：救えた' : 'おばあさん：救えなかった';
  let resultText;
  if(hoodSaved && grannySaved) resultText = '——少年は、間に合った。二人とも、家に帰った。';
  else if(hoodSaved && !grannySaved) resultText = '——少年は、赤頭巾だけを、間に合わせた。';
  else resultText = '——少年は、間に合わなかった。';
  GT.fillPage('result', resultText + '\n（' + hoodLine + '／' + grannyLine + '）');
  ending.summary = hoodLine+'　／　'+grannyLine;

  const lines = AFTER[ending.kind].concat(EPILOGUE[ending.kind],
    [{s:'',c:'narr',t:'第一話「赤い頭巾」　おわり',act:'end-card'}]);
  GT.beginDialogue(lines,null,showEndChoices);
});
// 最後の選択肢（本を開いたあとも、ここに戻ってくる）
function showEndChoices(){
  GT.beginDialogue([], [
    { label:'📖 本を開いて、読み返す', set:()=>GT.openBookModal(), after:[] },
    { label:'はじめから読む', set:()=>location.reload(), after:[] },
  ], showEndChoices);
}

/* 夜明けの外（マリと話す場面）：地形より奥 */
function drawEpilogue(){
  if(!GT.scene || GT.scene.type!=='end' || !ending.epilogue) return;
  const t=performance.now()/1000, FLOOR=H-EDGE;
  ctx.save();
  const sky=ctx.createLinearGradient(0,0,0,FLOOR);
  sky.addColorStop(0,'#5a6488'); sky.addColorStop(0.55,'#d9a27a'); sky.addColorStop(1,'#efd2a0');
  ctx.globalAlpha=0.85; ctx.fillStyle=sky; ctx.fillRect(0,0,W,H); ctx.globalAlpha=1;
  ell(700,FLOOR-40,60,60,'rgba(255,230,170,0.75)');                  // のぼる朝日
  ctx.fillStyle='rgba(70,64,60,0.55)';
  ctx.beginPath(); ctx.moveTo(0,FLOOR); ctx.quadraticCurveTo(300,330,600,380); ctx.quadraticCurveTo(780,410,W,350); ctx.lineTo(W,FLOOR); ctx.closePath(); ctx.fill();
  // 遠くのおばあさんの家（窓に明かり）
  ctx.fillStyle='rgba(60,52,44,0.9)'; ctx.fillRect(150,372,70,46);
  ctx.beginPath(); ctx.moveTo(142,374); ctx.lineTo(185,346); ctx.lineTo(228,374); ctx.closePath(); ctx.fill();
  ctx.fillStyle = ending.kind==='bad' ? 'rgba(120,110,90,0.6)' : `rgba(255,200,110,${0.8+0.1*Math.sin(t*4)})`; ctx.fillRect(172,388,12,12);
  // 木々のシルエット
  [[40,300,50],[300,320,44],[820,290,56]].forEach(([x,y,r])=>{ ctx.fillStyle='rgba(50,56,44,0.7)'; ctx.fillRect(x-4,y,8,FLOOR-y); ell(x,y,r*0.7,r,'rgba(50,56,44,0.7)'); });
  ctx.restore();
}
GT.registerDraw(drawEpilogue,'back');
/* マリ（engine の NPC と同じ形で描く） */
function drawMariEnd(){
  if(!GT.scene || GT.scene.type!=='end' || !ending.epilogue) return;
  const t=performance.now()/1000, x=520, foot=H-EDGE, hw=16, hh=20, bob=Math.sin(t*2.2)*2.2;
  ctx.save(); ctx.translate(x,foot-hh+bob);
  ctx.beginPath(); GT.roundRectPath(-hw,-hh,hw*2,hh*2,9); ctx.fillStyle='#4a4e6d'; ctx.fill();
  ctx.fillStyle='#a9b0d6'; ctx.beginPath(); ctx.moveTo(-4,-hh); ctx.lineTo(0,-hh-9); ctx.lineTo(4,-hh); ctx.closePath(); ctx.fill();
  ctx.fillStyle='#e8dcc0'; ctx.beginPath(); ctx.arc(5,-hh*0.35,2.4,0,Math.PI*2); ctx.arc(-5,-hh*0.35,2.4,0,Math.PI*2); ctx.fill();
  ctx.restore();
  ctx.save(); ctx.font="600 11px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.fillStyle='rgba(74,70,60,0.85)';
  ctx.fillText('マリ',x,foot-2*hh-12+bob); ctx.restore();
}
GT.registerDraw(drawMariEnd,'world');
/* エンディングの画面（最前面） */
function drawEndCard(){
  if(!GT.scene || GT.scene.type!=='end' || !ending.card) return;
  const k=Math.min(1,(performance.now()-ending.cardT)/1200), e=ENDINGS[ending.kind];
  const filled=GT.pageRecord.filter(p=>p.filled).length, all=GT.pageRecord.length;
  ctx.save(); ctx.globalAlpha=k;
  ctx.fillStyle='rgba(20,16,12,0.82)'; ctx.fillRect(0,0,W,H);
  ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillStyle='#b7ab8a'; ctx.font="600 16px 'Cormorant Garamond',serif"; ctx.fillText('G R A V I T Y   T A L E',W/2,70);
  ctx.fillStyle='#e8dcc0'; ctx.font="700 26px 'Zen Old Mincho',serif"; ctx.fillText('第一話「赤い頭巾」',W/2,110);
  ctx.strokeStyle='rgba(176,141,87,0.6)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(W/2-140,138); ctx.lineTo(W/2+140,138); ctx.stroke();
  ctx.fillStyle='#d9b877'; ctx.font="700 15px 'Zen Old Mincho',serif"; ctx.fillText('エンディング '+e.mark,W/2,166);
  ctx.fillStyle='#f3ead0'; ctx.font="700 30px 'Zen Old Mincho',serif"; ctx.fillText('「'+e.title+'」',W/2,204);
  ctx.fillStyle='#cbb98f'; ctx.font="500 14px 'Zen Old Mincho',serif";
  ctx.fillText(ending.summary||'',W/2,244);
  ctx.fillText('埋まったページ　'+filled+' / '+all,W/2,268);
  ctx.fillStyle='#8a8266'; ctx.font="500 13px 'Zen Old Mincho',serif"; ctx.fillText('〜 おわり 〜',W/2,300);
  ctx.restore();
}
GT.registerDraw(drawEndCard,'overlay');

// --- 到着・結末のシーン登録（並び順は playlist.js） ------------------------
GT.registerScene({ id:'arrive', type:'talk', stage:'wolf_boss', label:'第一話 ── おばあさんの家', dynamic:'arriveHouse' });
GT.registerScene({ id:'ending', type:'end',  label:'第一話・完', dynamic:'result' });

})();
