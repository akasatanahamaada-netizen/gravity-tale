/* ============================================================================
   ステージ：序 ── 森（オープニング）  id = 'opening'
   種類：story（ステージ上のキャラに話しかけて進む）
   担当：
   ----------------------------------------------------------------------------
   このファイルの直し方：
     ・地形を変える  → GT.defineStage(...) の platforms / items / decor
     ・セリフを変える → 下の「セリフ」の欄（MARI_FIRST など）
     ・登場人物     → npcs[].who は 'mari' / 'hood' / 'wolf' が使えます
   並び順を変えたいときは playlist.js を直してください。

   ◆ このステージの流れ
     1) まぶたが開くように画面が明るくなる。少年は地面に倒れている（act:'opening-lie'）
        空から、本のページが数枚ひらひら落ちてくる（少年が「落ちてきた」なごり）
     2) 本を開くと、虫食いだらけの白紙のページが見える（act:'opening-book-on' / 'off'）
     3) 操作できるようになると、少年が起き上がる。
        右ページの大きな木の陰から、マリがときどき顔をのぞかせている。
        背表紙をこえて近づくと、マリが「！」と木の陰から出てくる。
     4) ミッション：散らばった「本のかけら（★）」を 3つ 拾う
          ・丘のてっぺん          … 段をのぼる練習
          ・右ページの切り株の上    … ジャンプの練習
          ・倒れていた場所の葉の陰  … 「ちゃんと見て」（手前の葉に隠れている）
     5) マリと話す。拾った数でセリフが変わる。話したあとも、何度でもヒントをくれる。
     6) 話し終えて、かけらを全部拾うと、右の端が開く。

   ◆ このファイルが持っている独自の仕掛け（engine.js は触らない）
     GT.registerAct      … 'opening-lie' 'opening-book-on' 'opening-book-off'
     GT.registerUpdate   … マリの動き・セリフの切り替え
     GT.registerDraw     … 木漏れ日・落ち葉・散らばったページ・マリの木・本の絵・まぶた
   ========================================================================== */
(function(){
const ctx=GT.ctx, W=GT.W, H=GT.H, EDGE=GT.EDGE, FLOOR=H-GT.EDGE;

// --- 地形 ------------------------------------------------------------------
GT.defineStage('opening', {
  platforms:[
    // 左ページ：少年が落ちてきた小さな丘（3段）
    {page:'left', x:90,  y:420, w:140, h:40,  kind:'ledge'},
    {page:'left', x:180, y:380, w:160, h:80,  kind:'ledge'},
    {page:'left', x:280, y:340, w:150, h:120, kind:'ledge'},
    // 右ページ：切り株（ジャンプで乗る）
    {page:'right', x:520, y:380, w:56, h:84,  kind:'ledge'},
  ],
  boxes:[
  ],
  enemies:[
  ],
  items:[
    {page:'left',  x:340, y:296, w:40, h:40},   // 丘のてっぺん
    {page:'right', x:534, y:334, w:28, h:28},   // 切り株の上
    {page:'left',  x:22,  y:434, w:26, h:26},   // 倒れていた場所の葉の陰（手前の葉で隠れる）
  ],
  mission:['items'],
  decor:[
    {layer:'back',  kind:'tree',  x:180, y:130, w:120, h:250},
    {layer:'back',  kind:'tree',  x:470, y:100, w:110, h:320},
    {layer:'back',  kind:'tree',  x:20,  y:170, w:90,  h:250},
    {layer:'back',  kind:'bush',  x:370, y:296, w:70,  h:44},
    {layer:'back',  kind:'rock',  x:600, y:420, w:60,  h:44},
    {layer:'back',  kind:'bush',  x:780, y:420, w:80,  h:44},
    {layer:'front', kind:'fern',  x:-6,  y:388, w:96,  h:80},   // ★を隠す葉
    {layer:'front', kind:'grass', x:300, y:312, w:60,  h:30},
    {layer:'front', kind:'grass', x:470, y:432, w:70,  h:32},
    {layer:'front', kind:'grass', x:800, y:432, w:60,  h:32},
  ],
});

// --- セリフ ----------------------------------------------------------------
// 最初に話しかけたとき。拾ったかけらの数で、途中が変わる。
function MARI_FIRST(c){
  const rest=c.itemsAll-c.items;
  const head=[
    {s:'マリ',c:'mari',t:'あ、起きた。'},
    {s:'マリ',c:'mari',t:'だいじょうぶ？　落ちてきたとき、けっこう派手だったよ。'},
    {s:'',c:'narr',t:'少年は空を見上げる。重なりあった梢のすきまに、白い空が少しのぞいているだけだ。'},
    {s:'',c:'narr',t:'それから、抱えていた本に目を落とした。'},
    {s:'マリ',c:'mari',t:'……うん、それ。それが大事なの。'},
    {s:'マリ',c:'mari',t:'その本、全部埋めないと帰れないから。'},
    {s:'マリ',c:'mari',t:'進むだけじゃダメだよ。ちゃんと見て、ちゃんと話して。そしたら勝手に書かれるから。'},
    {s:'マリ',c:'mari',t:'飛ばしちゃダメ。一つでも空いてたら、完成しないの。'},
  ];
  const mid = rest>0 ? [
    {s:'マリ',c:'mari',t:'……ほら。落ちたときに、ページのかけらが散らばっちゃってる。'},
    {s:'マリ',c:'mari',t:`光ってるの、ぜんぶ拾って。あと ${rest}つ。`},
    {s:'マリ',c:'mari',t:'見えてるところにあるとは、かぎらないよ。'},
  ] : [
    {s:'マリ',c:'mari',t:'……あれ。散らばってたかけら、もう全部拾ったんだ。'},
    {s:'マリ',c:'mari',t:'ふうん。ちゃんと見てるじゃない。'},
  ];
  const tail=[
    {s:'',c:'narr',t:'少年が本を差し出す。「これでいいの？」というように。'},
    {s:'マリ',c:'mari',t:'……ううん。それは、あなたのだから。'},
    {s:'マリ',c:'mari',t:'あっちに、赤い頭巾の子がいる。……気をつけて。'},
  ];
  return head.concat(mid,tail);
}
// 2回目以降に話しかけたとき（ヒント）
function MARI_AGAIN(c, hiddenLeft){
  const rest=c.itemsAll-c.items;
  if(rest<=0) return [
    {s:'マリ',c:'mari',t:'もう行けるよ。右の端まで歩いて。'},
    {s:'マリ',c:'mari',t:'……わたし？　わたしは、まだここにいる。'},
  ];
  if(hiddenLeft) return [
    {s:'マリ',c:'mari',t:`あと ${rest}つ。`},
    {s:'マリ',c:'mari',t:'あなたが倒れてたところ、ちゃんと見た？　葉っぱの陰とか。'},
  ];
  return [
    {s:'マリ',c:'mari',t:`あと ${rest}つ。`},
    {s:'マリ',c:'mari',t:'高いところも、見てみて。'},
  ];
}

// --- シーン（会話と進行） --------------------------------------------------
GT.registerScene({
  id:'opening', type:'story', stage:'opening', label:'序 ── 森',
  intro:[
    {s:'',c:'narr',t:'森。仰向けに倒れた少年が、目を覚ます。手には一冊の本。',act:'opening-lie'},
    {s:'',c:'narr',t:'ページをめくると、ところどころ絵はあるが、大半は虫食いの白紙だった。',act:'opening-book-on'},
    {s:'',c:'narr',t:'まわりには、本から抜け落ちたらしいページのかけらが、ちらちらと光っている。',act:'opening-book-off'},
    {s:'',c:'narr',t:'（← → で歩く。↑ でジャンプ。人の近くで ▲ ボタン・画面タップ・Enter で話しかけられる）'},
    {s:'',c:'narr',t:'向こうの大きな木の陰から、だれかがこちらをうかがっている。'},
  ],
  npcs:[
    { who:'mari', name:'マリ', page:'right', x:710,
      lines:MARI_FIRST({items:0,itemsAll:3}),          // 実際は話しかける直前に作り直す（下の update）
      onEnd:()=>{ st.talkedOnce=true;
        GT.fillPage('prologue','——少年は、白紙の本とともに森で目を覚ました。木の陰にいた少女は、マリと名乗った。'); } }
  ],
});

/* ==========================================================================
   ここから下は、このステージ専用の演出
   ========================================================================== */
const MARI_HIDE_X=710, MARI_PEEK_X=674, MARI_OUT_X=630, MARI_SPEED=110;
const TRUNK={x:690, w:72};                 // マリが隠れる木の幹
const HIDDEN_ITEM=2;                       // items の何番目が「葉の陰」か

const st={
  t0:performance.now(), lieDone:false,
  book:{on:false,a:0}, last:performance.now(),
  mariOut:false, bangT:0, talkedOnce:false,
  startX:60, movedFar:false, gotSeen:[],
};
const isOpening=()=>GT.scene&&GT.scene.id==='opening';
const mariNpc=()=>GT.getNpcs().find(n=>n.who==='mari');

GT.registerSceneReset(()=>{
  if(!isOpening()) return;
  const now=performance.now();
  st.t0=now; st.last=now; st.lieDone=false; st.book.on=false; st.book.a=0;
  st.mariOut=false; st.bangT=0; st.talkedOnce=false; st.movedFar=false; st.gotSeen=[];
});

// 少年は地面に倒れている（会話中は物理が止まるので、平たいまま。操作できると起き上がる）
GT.registerAct('opening-lie',()=>{
  const pl=GT.player, sq=1.65;
  pl.squash=sq; pl.y=FLOOR-pl.h/2-(pl.h/2)*(2-sq);
});
GT.registerAct('opening-book-on', ()=>{ st.book.on=true; });
GT.registerAct('opening-book-off',()=>{ st.book.on=false; });

/* ---------- 毎フレームの処理（操作中だけ動く） ---------- */
GT.registerUpdate(dt=>{
  if(!isOpening()) return;
  const pl=GT.player, n=mariNpc(); if(!n) return;
  const pcx=pl.x+pl.w/2;
  if(Math.abs(pcx-(st.startX+pl.w/2))>90) st.movedFar=true;

  // マリ：はじめは木の陰。ときどき顔を出す。背表紙をこえて近づくと出てくる
  if(!st.mariOut && pcx>GT.SPINE+20){ st.mariOut=true; st.bangT=1.3; }
  let target;
  if(st.mariOut) target=MARI_OUT_X;
  else { const ph=((performance.now()-st.t0)/1000)%3.4; target=(ph>2.2&&ph<3.1)?MARI_PEEK_X:MARI_HIDE_X; }
  const step=(st.mariOut?MARI_SPEED:70)*dt;
  if(Math.abs(target-n.x)<=step) n.x=target; else n.x+=Math.sign(target-n.x)*step;
  st.bangT=Math.max(0,st.bangT-dt);

  // 木の陰にいるあいだは話しかけられない
  const c=GT.missionCount();
  n.talkable=st.mariOut;
  // 話しかける直前の状態でセリフを作る。1回話したあとは、ヒントを何度でもくれる
  if(!st.talkedOnce){ n.lines=MARI_FIRST(c); }
  else {
    if(n.talked){ n.talked=false; n.onEnd=null; }
    n.lines=MARI_AGAIN(c, !GT.items[HIDDEN_ITEM].got);
  }
});

/* ---------- 描画の小道具 ---------- */
function ell(x,y,rx,ry,c,rot){ ctx.beginPath(); ctx.ellipse(x,y,rx,ry,rot||0,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); }
const secs=()=>(performance.now()-st.t0)/1000;
// 決まった乱数（毎フレーム同じ値になる）
const rnd=i=>{ const s=Math.sin(i*127.1+311.7)*43758.5453; return s-Math.floor(s); };

/* 散らばったページ：空から落ちてきて、地面（丘）にとまる */
const PAGES=[
  {x:34,  y:FLOOR-3, rot:-0.25, delay:0.2},
  {x:120, y:417,     rot: 0.18, delay:0.9},
  {x:70,  y:FLOOR-3, rot: 0.40, delay:1.6},
  {x:230, y:377,     rot:-0.12, delay:2.3},
  {x:150, y:FLOOR-3, rot: 0.05, delay:3.0},
];
function drawPage(x,y,rot,a){
  ctx.save(); ctx.translate(x,y); ctx.rotate(rot); ctx.globalAlpha=a;
  ctx.fillStyle='#f6eed8'; ctx.fillRect(-13,-4,26,7);
  ctx.strokeStyle='rgba(90,74,51,0.45)'; ctx.lineWidth=1; ctx.strokeRect(-13,-4,26,7);
  ctx.fillStyle='rgba(90,74,51,0.35)'; ctx.fillRect(-9,-1.5,13,1); ctx.fillRect(-9,1,8,1);
  ctx.restore();
}
function drawPages(){
  const t=secs();
  PAGES.forEach((p,i)=>{
    const FALL=3.2, k=Math.min(1,Math.max(0,(t-p.delay)/FALL));
    if(k<=0) return;
    if(k>=1){ drawPage(p.x,p.y,p.rot,1); return; }
    // ひらひら左右にゆれながら落ちる
    const y=-20+(p.y+20)*k, sway=Math.sin(k*Math.PI*4+i)*30*(1-k);
    const rot=p.rot+Math.sin(k*Math.PI*5+i)*0.9*(1-k);
    ctx.save(); ctx.translate(p.x+sway,y); ctx.scale(1,0.4+0.6*Math.abs(Math.cos(k*9+i)));
    drawPage(0,0,rot,1); ctx.restore();
  });
}

/* 木漏れ日 */
function drawLightShafts(){
  const t=performance.now()/1000;
  ctx.save(); ctx.globalCompositeOperation='lighter';
  [[120,70,0.6],[330,50,1.7],[600,90,2.9],[760,40,4.1]].forEach(([x,w,s])=>{
    const a=0.022+0.012*Math.sin(t*0.7+s);
    const g=ctx.createLinearGradient(0,EDGE,0,FLOOR);
    g.addColorStop(0,`rgba(255,236,170,${a*1.6})`); g.addColorStop(1,'rgba(255,236,170,0)');
    ctx.fillStyle=g; ctx.beginPath();
    ctx.moveTo(x,EDGE); ctx.lineTo(x+w,EDGE); ctx.lineTo(x+w-110,FLOOR); ctx.lineTo(x-150,FLOOR); ctx.closePath(); ctx.fill();
  });
  // 光の中を漂うちり
  for(let i=0;i<22;i++){
    const x=(rnd(i)*W+Math.sin(t*0.3+i)*20)%W, y=EDGE+((rnd(i+50)*H+t*(6+rnd(i+9)*8))%(FLOOR-EDGE));
    ctx.globalAlpha=0.25+0.25*Math.sin(t*2+i); ell(x,y,1.2,1.2,'#fff2c0');
  }
  ctx.restore();
}

/* 落ち葉 */
function drawLeaves(){
  const t=performance.now()/1000;
  for(let i=0;i<9;i++){
    const sp=18+rnd(i+3)*16, span=FLOOR-EDGE+40;
    const y=EDGE-20+((t*sp+rnd(i)*span)%span);
    const x=rnd(i+20)*W+Math.sin(t*1.3+i*2)*26;
    const r=t*2+i;
    ell(x,y,5,2.4*Math.abs(Math.cos(r)),i%3?'rgba(122,128,74,0.75)':'rgba(176,141,87,0.75)',Math.sin(r)*0.8);
  }
}

/* マリが隠れる大きな木（マリより手前・少年より奥） */
function drawMariTree(){
  const x=TRUNK.x, w=TRUNK.w, top=110;
  ctx.save();
  // 根
  ctx.fillStyle='#4a3c2a';
  ctx.beginPath(); ctx.moveTo(x-22,FLOOR); ctx.quadraticCurveTo(x+4,FLOOR-14,x+8,FLOOR-40);
  ctx.lineTo(x+w-8,FLOOR-40); ctx.quadraticCurveTo(x+w-4,FLOOR-14,x+w+22,FLOOR); ctx.closePath(); ctx.fill();
  // 幹
  const g=ctx.createLinearGradient(x,0,x+w,0);
  g.addColorStop(0,'#4a3c2a'); g.addColorStop(0.45,'#5e4c35'); g.addColorStop(1,'#3e3223');
  ctx.fillStyle=g; ctx.beginPath();
  ctx.moveTo(x+6,FLOOR); ctx.lineTo(x+12,top); ctx.lineTo(x+w-12,top); ctx.lineTo(x+w-4,FLOOR); ctx.closePath(); ctx.fill();
  // 木肌のすじ・うろ
  ctx.strokeStyle='rgba(30,24,16,0.35)'; ctx.lineWidth=1.5;
  for(let i=0;i<5;i++){ const bx=x+16+i*10; ctx.beginPath(); ctx.moveTo(bx,top+20+i*13); ctx.quadraticCurveTo(bx+4,300,bx-2,FLOOR-30); ctx.stroke(); }
  ell(x+w*0.55,250,8,13,'#2e261b');
  // 葉のかたまり
  [[x+w/2,70,70,'#4f5d41'],[x-20,110,52,'#5e6e4b'],[x+w+18,100,50,'#5e6e4b'],[x+w/2,120,60,'#6a7d55']]
    .forEach(([cx,cy,r,c])=>{ ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); });
  ctx.restore();
}

/* 切り株の木肌 */
function drawStump(){
  const p={x:520,y:380,w:56,h:84};
  ctx.save();
  ctx.strokeStyle='rgba(40,32,22,0.35)'; ctx.lineWidth=1.4;
  for(let i=1;i<4;i++){ const bx=p.x+i*p.w/4; ctx.beginPath(); ctx.moveTo(bx,p.y+14); ctx.lineTo(bx+(i-2)*2,p.y+p.h); ctx.stroke(); }
  ctx.strokeStyle='rgba(232,220,192,0.35)'; ctx.lineWidth=1;
  ctx.beginPath(); ctx.ellipse(p.x+p.w/2,p.y+7,p.w*0.3,3,0,0,Math.PI*2); ctx.stroke();
  ctx.beginPath(); ctx.ellipse(p.x+p.w/2,p.y+7,p.w*0.14,1.5,0,0,Math.PI*2); ctx.stroke();
  ctx.restore();
}

/* 葉の陰のかけらが、ときどききらっと光る（見つけるヒント） */
function drawHiddenGlint(){
  const it=GT.items[HIDDEN_ITEM]; if(!it||it.got) return;
  const t=performance.now()/1000, k=(t%2.6)/2.6; if(k>0.35) return;
  const a=Math.sin(k/0.35*Math.PI), cx=it.x+it.w/2+4, cy=it.y+2;
  ctx.save(); ctx.globalAlpha=a; ctx.strokeStyle='#ffe9a0'; ctx.lineWidth=1.6;
  ctx.beginPath(); ctx.moveTo(cx-7,cy); ctx.lineTo(cx+7,cy); ctx.moveTo(cx,cy-7); ctx.lineTo(cx,cy+7); ctx.stroke();
  ctx.restore();
}

/* マリの「！」と、操作のヒント */
function drawMarks(){
  const n=mariNpc();
  if(n && st.bangT>0){
    const a=Math.min(1,st.bangT*3), jump=Math.max(0,st.bangT-1.0)*40;
    ctx.save(); ctx.globalAlpha=a; ctx.font="700 22px 'Zen Old Mincho',serif"; ctx.textAlign='center';
    ctx.fillStyle='#4a4e6d'; ctx.fillText('！', n.x+n.w/2, FLOOR-n.h-30-jump); ctx.restore();
  }
  if(GT.mode==='play' && !st.movedFar){
    const a=0.55+0.25*Math.sin(performance.now()/300);
    ctx.save(); ctx.globalAlpha=a; ctx.font="700 14px 'Zen Old Mincho',serif"; ctx.textAlign='left';
    ctx.fillStyle='rgba(74,70,60,0.9)'; ctx.fillText('← →  あるく　　↑  ジャンプ', 34, 170); ctx.restore();
  }
}

/* 本の絵（虫食いのページ） */
function drawBookView(){
  const now=performance.now(), dt=Math.min(0.1,(now-st.last)/1000); st.last=now;
  st.book.a+=((st.book.on?1:0)-st.book.a)*Math.min(1,dt*6);
  if(st.book.a<0.01) return;
  const cx=W/2, cy=180, pw=220, ph=250;
  ctx.save(); ctx.globalAlpha=st.book.a;
  ctx.fillStyle='rgba(24,20,14,0.82)'; ctx.fillRect(0,0,W,H);
  // 表紙
  GT.roundRect(cx-pw-14,cy-ph/2-10,pw*2+28,ph+20,8); ctx.fillStyle='#5a3f2e'; ctx.fill();
  // ページ
  for(const side of [-1,1]){
    const x0=side<0?cx-pw:cx;
    const g=ctx.createLinearGradient(x0,0,x0+pw,0);
    if(side<0){ g.addColorStop(0,'#efe4c8'); g.addColorStop(0.85,'#e6d8b4'); g.addColorStop(1,'#c9b88e'); }
    else      { g.addColorStop(0,'#c9b88e'); g.addColorStop(0.15,'#e6d8b4'); g.addColorStop(1,'#efe4c8'); }
    ctx.fillStyle=g; ctx.fillRect(x0,cy-ph/2,pw,ph);
  }
  // 左ページ：かすれた絵（木と、赤い頭巾の小さな人影）と、文字の行
  ctx.strokeStyle='rgba(90,74,51,0.55)'; ctx.lineWidth=1.4;
  ctx.beginPath(); ctx.moveTo(cx-150,cy+10); ctx.lineTo(cx-150,cy-40); ctx.stroke();
  ctx.beginPath(); ctx.arc(cx-150,cy-58,24,0,Math.PI*2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(cx-190,cy+10); ctx.lineTo(cx-40,cy+10); ctx.stroke();
  ctx.fillStyle='rgba(184,66,63,0.55)';
  ctx.beginPath(); ctx.moveTo(cx-90,cy+10); ctx.lineTo(cx-80,cy-16); ctx.lineTo(cx-70,cy+10); ctx.closePath(); ctx.fill();
  ell(cx-80,cy-20,6,6,'rgba(184,66,63,0.55)');
  ctx.fillStyle='rgba(90,74,51,0.4)';
  for(let i=0;i<5;i++) ctx.fillRect(cx-pw+24, cy+34+i*14, (i===4?90:170)-rnd(i)*40, 2);
  // 右ページ：ほとんど白紙。1行だけ
  ctx.fillRect(cx+24, cy-ph/2+30, 120, 2);
  // 虫食いの穴
  const holes=[[-170,-90,10],[-120,60,7],[-40,-70,12],[-60,90,6],[40,-60,14],[110,-20,9],[70,40,16],[150,80,8],[170,-90,6],[30,100,10],[-190,20,6]];
  holes.forEach(([hx,hy,r],i)=>{
    ctx.beginPath();
    for(let k=0;k<9;k++){ const a=k/9*Math.PI*2, rr=r*(0.7+0.5*rnd(i*9+k)); ctx.lineTo(cx+hx+Math.cos(a)*rr, cy+hy+Math.sin(a)*rr); }
    ctx.closePath(); ctx.fillStyle='#2b2418'; ctx.fill();
    ctx.strokeStyle='rgba(139,110,70,0.6)'; ctx.lineWidth=1.2; ctx.stroke();
  });
  // のど（真ん中の影）
  const sg=ctx.createLinearGradient(cx-14,0,cx+14,0);
  sg.addColorStop(0,'rgba(58,50,38,0)'); sg.addColorStop(0.5,'rgba(58,50,38,0.45)'); sg.addColorStop(1,'rgba(58,50,38,0)');
  ctx.fillStyle=sg; ctx.fillRect(cx-14,cy-ph/2,28,ph);
  ctx.restore();
}

/* 目を覚ます：まぶたが2回ひらく */
function drawWake(){
  const t=secs(); if(t>3.2) return;
  const k=(a,b,x)=>Math.min(1,Math.max(0,(x-a)/(b-a)));
  let open;
  if(t<0.7) open=0;
  else if(t<1.2) open=0.35*k(0.7,1.2,t);
  else if(t<1.5) open=0.35-0.3*k(1.2,1.5,t);
  else open=0.05+0.95*(1-Math.pow(1-k(1.5,3.0,t),2));
  const lid=(1-open)*(H/2+30);
  ctx.save(); ctx.fillStyle='#120e09';
  ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(W,0); ctx.lineTo(W,lid-30); ctx.quadraticCurveTo(W/2,lid+30,0,lid-30); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(0,H); ctx.lineTo(W,H); ctx.lineTo(W,H-lid+30); ctx.quadraticCurveTo(W/2,H-lid-30,0,H-lid+30); ctx.closePath(); ctx.fill();
  // まだぼんやりしている
  ctx.globalAlpha=0.5*(1-open); ctx.fillRect(0,0,W,H);
  ctx.restore();
}

GT.registerDraw(()=>{ if(!isOpening()) return; drawLightShafts(); drawPages(); }, 'back');
GT.registerDraw(()=>{ if(!isOpening()) return; drawStump(); drawMariTree(); drawLeaves(); drawMarks(); }, 'world');
GT.registerDraw(()=>{ if(!isOpening()) return; drawHiddenGlint(); drawBookView(); drawWake(); }, 'overlay');
})();
