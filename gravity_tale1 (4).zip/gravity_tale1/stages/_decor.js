/* ============================================================================
   飾りオブジェクト（当たり判定なし）  _decor.js
   ----------------------------------------------------------------------------
   ★ 飾りの「種類」はこのファイル 1つで決まります。
     ここに 1つ足すだけで、ゲームにもエディタ(editor.html)にも自動で出ます。
     （index.html / editor.html / engine.js は、もう触らなくてOK）

   - layer:'back'  … 奥（地形より後ろ）に描く
   - layer:'front' … 手前（プレイヤーより前）に描く
   - w,h           … 置いたときの標準サイズ（あとで自由に変えられる）
   - draw(ctx,x,y,w,h) … 枠 (x,y,w,h) の中に描く関数。engine が無くても動く純粋関数。

   使い方（ステージ側の書き出しに、この配列が入ります）：
     GT.defineStage('id', {
       platforms:[...], boxes:[...], enemies:[...],
       decor:[
         {layer:'back',  kind:'tree',  x:120, y:180, w:90,  h:150},
         {layer:'front', kind:'grass', x:300, y:430, w:70,  h:34 },
       ],
     });
   ========================================================================== */
(function(){
"use strict";
const api = (window.GTDecor = window.GTDecor || {});

/* ===== 飾りの種類：ここに足す ============================================= */
const TYPES = {
  tree:  { label:'木',    layer:'back',  w:90,  h:150, draw:drawTree  },
  bush:  { label:'茂み',  layer:'back',  w:80,  h:46,  draw:drawBush  },
  cloud: { label:'雲',    layer:'back',  w:120, h:50,  draw:drawCloud },
  moon:  { label:'月',    layer:'back',  w:60,  h:60,  draw:drawMoon  },
  rock:  { label:'岩',    layer:'back',  w:70,  h:46,  draw:drawRock  },
  grass: { label:'草',    layer:'front', w:70,  h:34,  draw:drawGrass },
  fern:  { label:'前の葉',layer:'front', w:100, h:80,  draw:drawFern  },
  ledgeBack:  { label:'足場(奥)',  layer:'back',  w:120, h:20, draw:drawLedge },
  ledgeFront: { label:'足場(手前)',layer:'front', w:120, h:20, draw:drawLedge },
};
api.TYPES = TYPES;
api.draw  = function(ctx,kind,x,y,w,h){ const d=TYPES[kind]; if(d&&d.draw) d.draw(ctx,x,y,w,h); };

/* ===== 小道具 ============================================================= */
function blob(ctx,cx,cy,r,c){ ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); }
function ell(ctx,cx,cy,rx,ry,c){ ctx.beginPath(); ctx.ellipse(cx,cy,rx,ry,0,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); }

/* ===== 描画関数 =========================================================== */
function drawTree(ctx,x,y,w,h){
  const cx=x+w/2, trunkW=Math.max(6,w*0.16), trunkH=h*0.40;
  ctx.save();
  ctx.fillStyle='#5a4a33'; ctx.fillRect(cx-trunkW/2, y+h-trunkH, trunkW, trunkH);
  const cyF=y+h-trunkH-w*0.2, fr=w*0.34;
  blob(ctx,cx,          cyF-fr*0.5, fr,      '#4f5d41');
  blob(ctx,cx-fr*0.72,  cyF,        fr*0.85, '#5e6e4b');
  blob(ctx,cx+fr*0.72,  cyF,        fr*0.85, '#5e6e4b');
  blob(ctx,cx,          cyF+fr*0.25,fr*0.98, '#6a7d55');
  ctx.restore();
}
function drawBush(ctx,x,y,w,h){
  const by=y+h; ctx.save();
  ell(ctx,x+w*0.3, by-h*0.4,  w*0.3,  h*0.5, '#4f5d41');
  ell(ctx,x+w*0.7, by-h*0.4,  w*0.3,  h*0.5, '#5e6e4b');
  ell(ctx,x+w*0.5, by-h*0.55, w*0.34, h*0.6, '#657a52');
  ctx.restore();
}
function drawCloud(ctx,x,y,w,h){
  const cy=y+h*0.6, c='rgba(243,234,208,0.92)'; ctx.save();
  ell(ctx,x+w*0.30,cy,       w*0.26,h*0.50,c);
  ell(ctx,x+w*0.55,cy-h*0.12,w*0.30,h*0.60,c);
  ell(ctx,x+w*0.75,cy,       w*0.24,h*0.46,c);
  ell(ctx,x+w*0.50,cy+h*0.15,w*0.40,h*0.40,c);
  ctx.restore();
}
function drawMoon(ctx,x,y,w,h){
  const cx=x+w/2, cy=y+h/2, r=Math.min(w,h)/2; ctx.save();
  const g=ctx.createRadialGradient(cx,cy,r*0.4,cx,cy,r*1.7);
  g.addColorStop(0,'rgba(232,220,192,0.5)'); g.addColorStop(1,'rgba(232,220,192,0)');
  ctx.fillStyle=g; ctx.beginPath(); ctx.arc(cx,cy,r*1.7,0,Math.PI*2); ctx.fill();
  blob(ctx,cx,cy,r,'#e6dcc0');
  ctx.fillStyle='rgba(120,110,80,0.18)';
  ctx.beginPath(); ctx.arc(cx-r*0.3,cy-r*0.2,r*0.18,0,Math.PI*2); ctx.arc(cx+r*0.25,cy+r*0.3,r*0.12,0,Math.PI*2); ctx.fill();
  ctx.restore();
}
function drawRock(ctx,x,y,w,h){
  const by=y+h; ctx.save();
  ctx.fillStyle='#6f6659'; ctx.beginPath();
  ctx.moveTo(x,by); ctx.lineTo(x+w*0.2,y+h*0.35); ctx.lineTo(x+w*0.55,y+h*0.1);
  ctx.lineTo(x+w*0.82,y+h*0.4); ctx.lineTo(x+w,by); ctx.closePath(); ctx.fill();
  ctx.fillStyle='rgba(232,220,192,0.18)'; ctx.beginPath();
  ctx.moveTo(x+w*0.55,y+h*0.1); ctx.lineTo(x+w*0.82,y+h*0.4); ctx.lineTo(x+w*0.6,y+h*0.45); ctx.closePath(); ctx.fill();
  ctx.restore();
}
/* 床の足場（engine.js の ledge）と同じ見た目。重力が逆のページでは光の筋も下側へ */
function drawLedge(ctx,x,y,w,h){
  const G=window.GT, page=(G&&x+w/2>=G.SPINE)?'right':'left';
  const inv=!!(G&&G.gravity&&G.gravity[page]===-1), r=9;
  ctx.save();
  ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r);
  ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath();
  ctx.fillStyle='#6b5b46'; ctx.fill();
  ctx.fillStyle='rgba(232,220,192,0.28)';
  if(!inv) ctx.fillRect(x+4,y+2,w-8,3); else ctx.fillRect(x+4,y+h-5,w-8,3);
  ctx.restore();
}
function drawGrass(ctx,x,y,w,h){
  ctx.save(); ctx.strokeStyle='#5e6e4b'; ctx.lineWidth=Math.max(2,w*0.035); ctx.lineCap='round';
  const base=y+h, n=Math.max(4,Math.floor(w/10));
  for(let i=0;i<n;i++){ const bx=x+(i+0.5)*(w/n), lean=((i%3)-1)*h*0.22;
    ctx.beginPath(); ctx.moveTo(bx,base); ctx.quadraticCurveTo(bx+lean*0.5,base-h*0.6,bx+lean,base-h); ctx.stroke(); }
  ctx.restore();
}
function drawFern(ctx,x,y,w,h){
  ctx.save(); ctx.fillStyle='rgba(66,80,55,0.92)';
  const bx=x+w*0.5, by=y+h;
  for(let i=0;i<5;i++){ const t=i/4, ang=-0.7+t*1.4;
    const ex=bx+Math.sin(ang)*w*0.5, ey=by-h*(0.55+0.45*(1-Math.abs(t-0.5)*2));
    leaf(ctx,bx,by,ex,ey,w*0.11); }
  ctx.restore();
}
function leaf(ctx,x0,y0,x1,y1,width){
  const mx=(x0+x1)/2,my=(y0+y1)/2, nx=-(y1-y0),ny=(x1-x0), len=Math.hypot(nx,ny)||1;
  const ox=nx/len*width, oy=ny/len*width;
  ctx.beginPath(); ctx.moveTo(x0,y0); ctx.quadraticCurveTo(mx+ox,my+oy,x1,y1);
  ctx.quadraticCurveTo(mx-ox,my-oy,x0,y0); ctx.fill();
}

/* ===== ゲーム本体に組み込む（engine.js があるときだけ動く） =============== */
if(window.GT && GT.registerDraw){
  function drawLayer(layer){
    const sc=GT.scene; if(!sc||!sc.stage) return;
    const def=GT.STAGE_DEFS[sc.stage]; if(!def||!def.decor) return;
    for(const d of def.decor){ if((d.layer||'back')===layer) api.draw(GT.ctx,d.kind,d.x,d.y,d.w,d.h); }
  }
  GT.registerDraw(()=>drawLayer('back'),  'back');     // 地形より奥
  GT.registerDraw(()=>drawLayer('front'), 'overlay');  // プレイヤーより手前
}
})();
