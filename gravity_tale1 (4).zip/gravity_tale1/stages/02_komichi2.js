/* ============================================================================
   ステージ：序 ── 森の小道 ②  id = 'komichi2'
   種類：play　道をふさぐ壁を、重力反転で天井づたいに越える
   担当：
   ========================================================================== */

GT.defineStage('komichi2', {
  platforms:[
    {page:'left', x:340, y:20, w:45, h:180, kind:'ledge'},
    {page:'left', x:270, y:310, w:120, h:150, kind:'ledge'},
    {page:'right', x:650, y:350, w:120, h:30, kind:'ledge'},
    {page:'left', x:270, y:290, w:150, h:40, kind:'ledge'},
    {page:'left', x:220, y:320, w:60, h:140, kind:'ledge'},
  ],
  boxes:[
    {x:110, y:420, w:40, h:40},
    {x:690, y:320, w:40, h:30},
  ],
  enemies:[
    {page:'right', x:810, y:430, w:40, h:30, dir:-1},
  ],
  mission:['enemies'],
  decor:[
    {layer:'back', kind:'ledgeBack', x:650, y:360, w:120, h:100},
  ],
});

GT.registerScene({
  id:'komichi2', type:'play', stage:'komichi2', clear:'exit', label:'序 ── 森の小道 ②',
  intro:{s:'',c:'narr',t:'道をふさぐ壁。本を裏返して重力を変え、天井づたいに越えよう。'},
});
