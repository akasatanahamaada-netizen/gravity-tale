/* ============================================================================
   ステージ：序 ── 森の小道 ①  id = 'komichi1'
   種類：play（右へ進んで、右ページの右端まで行くとクリア）
   担当：
   ----------------------------------------------------------------------------
   play ステージの作り方：
     ・clear:'exit'  … 右端まで歩き抜けるとクリア（横スクロール型）
     ・platforms     … 足場。page は 'left' / 'right'、kind は
                        'ledge'(床の足場) か 'ceilingLedge'(天井の足場)
     ・enemies       … 歩く敵（踏まれると往復。箱を落として倒せる）
     ・intro         … ステージ開始時に出るナレーション（省略可）
   ========================================================================== */

GT.defineStage('komichi1', {
platforms:[
    {page:'left', x:310, y:130, w:105, h:60, kind:'ledge'},
    {page:'left', x:350, y:190, w:25, h:275, kind:'ledge'},
    {page:'right', x:790, y:10, w:20, h:145, kind:'ledge'},
    {page:'left', x:180, y:360, w:110, h:100, kind:'ledge'},
    {page:'right', x:680, y:310, w:130, h:150, kind:'ledge'},
    {page:'right', x:760, y:360, w:80, h:100, kind:'ledge'},
    {page:'right', x:650, y:330, w:120, h:130, kind:'ledge'},
    {page:'left', x:290, y:170, w:140, h:90, kind:'ledge'},
    {page:'left', x:140, y:400, w:60, h:60, kind:'ledge'},
  ],
  boxes:[
  ],
  enemies:[
  ],
  items:[
    {page:'left', x:220, y:330, w:30, h:20},
    {page:'left', x:220, y:20, w:20, h:30},
    {page:'right', x:610, y:30, w:20, h:20},
    {page:'right', x:710, y:280, w:20, h:20},
  ],
  mission:['items'],
});

GT.registerScene({
  id:'komichi1', type:'play', stage:'komichi1', clear:'exit', label:'序 ── 森の小道 ①',
  intro:{s:'',c:'narr',t:'右へ進もう。ページのいちばん右の端まで行くと、ページがめくれて次へ進む。'},
});
