/* ============================================================================
   ステージ：第一話 ── 分かれ道  id = 'crossroads'
   種類：story　近道か遠回りかを選ぶ（flags.route）
   担当：
   ----------------------------------------------------------------------------
   ここで選んだ flags.route（'shortcut' / 'detour'）が結末を分けます。
     近道(shortcut)  … 狼を追い、おばあさんを助けられる可能性がある
                        近道のときだけ、近道のステージ（08_path2.js）を通る
     遠回り(detour)  … 安全だが遅く、着いたときにはおばあさんは…
                        遠回りのときだけ、遠回りの道①②（09_path3.js / 10_path4.js）を通る

   ◆ このステージの流れ（道は「歩いて」選ぶ）
     1) 分かれ道の手前で、赤ずきんが待っている。話しかけると、二つの道を教えてくれる。
     2) 右ページで道が分かれる。
          上の道（近道）… 本を裏返して、天井づたいに行く。暗いいばらの道。狼の足あとが続く。
                          垂れさがるいばらを、ジャンプでよけて進む。
          下の道（遠回り）… 床をそのまま行く。明るいが、ぬかるみで足が遅くなる。先に風車小屋。
     3) 道の終わり近くまで行くと「この道を行く／引き返す」をたずねられる。
        行くと決めると flags.route が決まり、右の端から次へ。
        遠回りなら赤ずきんがついてくる。近道なら、赤ずきんとはここで別れる。

   ◆ このファイルが持っている独自の仕掛け（engine.js は触らない）
     GT.registerUpdate … 赤ずきんの動き・話しかける前のセリフ作り・道の確認
     GT.registerDraw   … いばらの近道・明るい遠回り・風車小屋・道しるべ・案内
   ========================================================================== */
(function(){
const ctx=GT.ctx, W=GT.W, H=GT.H, EDGE=GT.EDGE, FLOOR=H-GT.EDGE, SPINE=GT.SPINE;
const HOOD_WAIT=392;                        // 赤ずきんが待っている場所
const DECIDE_X=780;                         // ここまで来たら「この道を行く？」
const SIGN_X=478;                           // 道しるべ
const THORN1={page:'right', x:610, y:EDGE, w:30, h:46, kind:'ceilingLedge'};   // 天井から垂れさがるいばら
const THORN2={page:'right', x:722, y:EDGE, w:30, h:56, kind:'ceilingLedge'};
const MUD   ={page:'right', x:560, y:446, w:200, h:18, slow:0.35, jump:0.6};  // 遠回りのぬかるみ

// --- 地形 ------------------------------------------------------------------
GT.defineStage('crossroads', {
  platforms:[ THORN1, THORN2 ],
  boxes:[], enemies:[],
  swamps:[ MUD ],
  decor:[
    {layer:'back',  kind:'tree',  x:20,  y:120, w:110, h:300},
    {layer:'back',  kind:'tree',  x:170, y:150, w:100, h:270},
    {layer:'back',  kind:'tree',  x:300, y:100, w:110, h:320},
    {layer:'back',  kind:'bush',  x:110, y:420, w:80,  h:44},
    {layer:'front', kind:'fern',  x:-8,  y:396, w:80,  h:72},
    {layer:'front', kind:'grass', x:240, y:434, w:60,  h:30},
    {layer:'front', kind:'grass', x:780, y:434, w:60,  h:30},
  ],
});

// --- セリフ ----------------------------------------------------------------
function HOOD_LINES(){
  return [
    {s:'',c:'narr',t:'森の分かれ道。古い道しるべが、ななめに傾いている。'},
    {s:'赤ずきん',c:'hood',t:'ここで、道が分かれるの。'},
    {s:'赤ずきん',c:'hood',t:'上の道は近道。……でも、狼さんが入っていったのも、あっち。'},
    {s:'赤ずきん',c:'hood',t:'下の道は、風車小屋をまわる遠回り。ぬかるんでるけど、明るくて安全よ。'},
    ...(GT.flags.warnedHood ? [
      {s:'赤ずきん',c:'hood',t:'……さっきの話、ずっと気になってるの。狼さんが、おばあちゃんのところへ行ってたら……'},
    ] : [
      {s:'赤ずきん',c:'hood',t:'狼さんと競争だもの。でも、わたしはいつもの道がいいな。'},
    ]),
    {s:'',c:'narr',t:'近道は、狼が向かったかもしれない。遠回りは、確実だが遅い。'},
    {s:'',c:'narr',t:'（本を裏返して上の近道を行くか、そのまま下の遠回りを行くか。歩いて、道を選ぼう）'},
  ];
}
const ROUTES={
  shortcut:{
    ask:[ {s:'',c:'narr',t:'いばらの奥へ、獣の足あとが続いている。この先は、少年ひとりの道だ。'} ],
    choices:[
      { label:'近道を行く（狼を追う）', set:()=>{ GT.flags.route='shortcut'; }, after:[
        {s:'赤ずきん',c:'hood',t:'（下の道から）……気をつけてね！　おばあちゃんのお家で、会おうね！'},
        {s:'',c:'narr',t:'少年は赤ずきんと別れ、近道を駆けた。狼より先に、おばあさんの家へ。'} ]},
      { label:'引き返す', after:[] },
    ]},
  detour:{
    ask:[ {s:'',c:'narr',t:'道は、風車小屋のほうへ大きくまわっている。赤ずきんが、となりで待っている。'} ],
    choices:[
      { label:'遠回りを行く（赤ずきんと一緒に）', set:()=>{ GT.flags.route='detour'; }, after:[
        {s:'赤ずきん',c:'hood',t:'うん、一緒に行こう。'},
        {s:'',c:'narr',t:'二人は安全な遠回りを選んだ。だが、その分だけ時間がかかる。'} ]},
      { label:'引き返す', after:[] },
    ]},
};

// --- シーン ----------------------------------------------------------------
GT.registerScene({
  id:'crossroads', type:'story', stage:'crossroads', label:'第一話 ── 分かれ道',
  intro:{s:'',c:'narr',t:'森の分かれ道。赤ずきんが、少年を待っている。',act:'cross-setup'},
  npcs:[
    { who:'hood', name:'赤ずきん', page:'left', x:HOOD_WAIT, lines:HOOD_LINES(),   // 話しかける直前に作り直す
      onEnd:()=>{ st.talked=true; } },
  ],
});

/* ==========================================================================
   選んだ道のときだけ遊ぶステージ
     dynamic:'shortcutOnly' … 近道のときだけ（08_path2.js）。遠回りのときは飛ばす
     dynamic:'detourOnly'   … 遠回りのときだけ（09_path3.js / 10_path4.js）。近道のときは飛ばす
   ========================================================================== */
function onlyOnRoute(route){
  return scene=>{
    if(GT.flags.route!==route){ GT.advanceScene(); return; }
    // dynamic を外した写しで、ふつうのシーンとして始め直す（始めたら元に戻す。次に遊ぶときもまた道を見る）
    const plain=Object.assign({},scene); delete plain.dynamic;
    GT.SCENES[GT.sceneIndex]=plain; GT.startScene(GT.sceneIndex); GT.SCENES[GT.sceneIndex]=scene;
  };
}
GT.registerDynamic('shortcutOnly', onlyOnRoute('shortcut'));
GT.registerDynamic('detourOnly',   onlyOnRoute('detour'));

/* ==========================================================================
   進行
   ========================================================================== */
const st={ talked:false, busy:false, bubble:null, last:performance.now() };
const isCross=()=>GT.scene&&GT.scene.id==='crossroads';
const hoodNpc=()=>GT.getNpcs().find(n=>n.who==='hood');
// いまどちらの道にいるか（右ページを裏返して天井にいれば近道）
const pathOf=()=> (GT.gravity.right===-1 && GT.player.y<H/2) ? 'shortcut' : 'detour';
GT.registerSceneReset(()=>{ if(isCross()){ st.talked=false; st.busy=false; st.bubble=null; } });
GT.registerAct('cross-setup',()=>{ GT.flags.route=null; const h=hoodNpc(); if(h) h.x=HOOD_WAIT; });

function autoTalk(lines,choices,after){
  st.busy=true; GT.mode='idle'; GT.player.vx=0;
  GT.beginDialogue(lines,choices,()=>{ GT.hideDialogue(); GT.mode='play'; st.busy=false; if(after) after(); });
}

GT.registerUpdate(()=>{
  if(!isCross()) return;
  const pl=GT.player, pcx=pl.x+pl.w/2, h=hoodNpc();
  if(h && !st.talked) h.lines=HOOD_LINES();
  if(st.busy || !st.talked) return;
  // 道の終わり近く：その道で決まっていなければ、たずねる
  const path=pathOf();
  if(pcx>DECIDE_X && GT.flags.route!==path){
    const r=ROUTES[path];
    autoTalk(r.ask, r.choices, ()=>{
      if(GT.flags.route!==path){ pl.x=DECIDE_X-140; pl.vx=0; }           // 引き返した
      else if(path==='shortcut') st.bubble={text:'気をつけてね！',t:2.4};
    });
  }
});

/* 赤ずきんの動き（会話中も動けるよう、描画のついでに進める）
   話す前：待っている / 話したあと：道しるべの前 / 遠回り：ついてくる / 近道：下の道を歩いていく */
function moveHood(){
  const h=hoodNpc(); if(!h) return;
  const now=performance.now(), dt=Math.min(0.05,(now-st.last)/1000); st.last=now;
  if(st.bubble){ st.bubble.t-=dt; if(st.bubble.t<=0) st.bubble=null; }
  if(!st.talked) return;
  const pcx=GT.player.x+GT.player.w/2;
  let target, speed=200;
  if(GT.flags.route==='detour') target=pcx+(pcx>h.x+16?-42:42)-16;
  else if(GT.flags.route==='shortcut'){ target=W+60; speed=60; }
  else target=SIGN_X-44;
  if(GT.mode!=='play' && GT.flags.route!=='shortcut') return;
  const dx=target-h.x; if(Math.abs(dx)>6) h.x+=Math.sign(dx)*Math.min(speed*dt,Math.abs(dx));
}

/* ==========================================================================
   描画
   ========================================================================== */
function ell(x,y,rx,ry,c){ ctx.beginPath(); ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2); ctx.fillStyle=c; ctx.fill(); }

/* 右ページ：上は暗いいばらの近道、下は明るい遠回り（地形より奥） */
function drawRoutes(){
  const t=performance.now()/1000;
  ctx.save();
  // 遠回り：右下から差す明るい光
  const sun=ctx.createRadialGradient(840,FLOOR-40,20,840,FLOOR-40,360);
  sun.addColorStop(0,'rgba(255,226,150,0.35)'); sun.addColorStop(1,'rgba(255,226,150,0)');
  ctx.fillStyle=sun; ctx.fillRect(SPINE,140,W-SPINE,FLOOR-140);
  // 遠くの丘と風車小屋
  ctx.fillStyle='rgba(120,140,100,0.35)';
  ctx.beginPath(); ctx.moveTo(SPINE,FLOOR); ctx.quadraticCurveTo(640,330,W,360); ctx.lineTo(W,FLOOR); ctx.closePath(); ctx.fill();
  const mx=815, my=372;
  ctx.fillStyle='rgba(110,92,72,0.75)';
  ctx.beginPath(); ctx.moveTo(mx-16,my+50); ctx.lineTo(mx-10,my); ctx.lineTo(mx+10,my); ctx.lineTo(mx+16,my+50); ctx.closePath(); ctx.fill();
  ctx.beginPath(); ctx.moveTo(mx-13,my); ctx.lineTo(mx,my-12); ctx.lineTo(mx+13,my); ctx.closePath(); ctx.fill();
  ctx.save(); ctx.translate(mx,my+2); ctx.rotate(t*0.6); ctx.fillStyle='rgba(232,220,192,0.8)';
  for(let i=0;i<4;i++){ ctx.rotate(Math.PI/2); ctx.fillRect(-2,-34,4,32); ctx.fillRect(1,-34,7,24); }
  ctx.restore(); ell(mx,my+2,3,3,'#5a4630');
  // 近道：天井側の暗いいばら
  ctx.save(); ctx.translate(690,EDGE); ctx.scale(1.4,0.6);          // 横長の影（ふちはぼかす）
  const dark=ctx.createRadialGradient(0,0,20,0,0,260);
  dark.addColorStop(0,'rgba(28,24,20,0.6)'); dark.addColorStop(1,'rgba(28,24,20,0)');
  ctx.fillStyle=dark; ctx.fillRect(-260,0,520,260); ctx.restore();
  ctx.fillStyle='rgba(44,52,38,0.92)';
  for(let i=0;i<10;i++){ const x=500+i*42, r=18+((i*5)%3)*7; ctx.beginPath(); ctx.arc(x,EDGE,r,0,Math.PI); ctx.fill(); }
  // 天井の獣の足あと（逆さに歩いた跡）
  for(let i=0;i<6;i++){ const x=520+i*58, y=EDGE+4+(i%2);
    ell(x,y,6,2.4,'rgba(20,16,12,0.6)'); for(let k=-1;k<=1;k++) ell(x+5+k*4,y+3,1.6,1.2,'rgba(20,16,12,0.6)'); }
  ctx.restore();
}

/* 道しるべ */
function drawSign(){
  const x=SIGN_X;
  ctx.save();
  ctx.fillStyle='#6b4f36'; ctx.fillRect(x-3,330,6,FLOOR-330);
  const board=(y,dir,txt,c,tilt)=>{
    ctx.save(); ctx.translate(x,y); ctx.rotate(tilt);
    ctx.beginPath(); ctx.moveTo(-8,-11); ctx.lineTo(62,-11); ctx.lineTo(74,0); ctx.lineTo(62,11); ctx.lineTo(-8,11); ctx.closePath();
    ctx.fillStyle=c; ctx.fill(); ctx.strokeStyle='rgba(40,30,20,0.5)'; ctx.lineWidth=1.2; ctx.stroke();
    ctx.fillStyle='#f3ead0'; ctx.font="700 12px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillText(txt,30,1); ctx.restore(); };
  board(342,1,'近道 ↑','#6b2f2a',-0.35);
  board(372,1,'遠回り','#8b6a43',0.05);
  ctx.restore();
}

/* いばら（天井から垂れさがる足場）にとげを描く */
function drawThorns(){
  ctx.save(); ctx.fillStyle='#2e3626';
  for(const p of [THORN1,THORN2]){
    GT.roundRect(p.x,p.y,p.w,p.h,8); ctx.fill();
    for(let y=p.y+8;y<p.y+p.h;y+=10){
      ctx.beginPath(); ctx.moveTo(p.x,y); ctx.lineTo(p.x-7,y+3); ctx.lineTo(p.x,y+6); ctx.fill();
      ctx.beginPath(); ctx.moveTo(p.x+p.w,y+4); ctx.lineTo(p.x+p.w+7,y+7); ctx.lineTo(p.x+p.w,y+10); ctx.fill(); }
  }
  ctx.restore();
}

/* 道の案内・選んだ道・ふきだし */
function drawGuide(){
  const t=performance.now()/1000;
  ctx.save(); ctx.font="700 14px 'Zen Old Mincho',serif"; ctx.textAlign='center'; ctx.textBaseline='middle';
  if(st.talked && !GT.flags.route && !st.busy){
    ctx.globalAlpha=0.6+0.3*Math.sin(t*3.5);
    ctx.fillStyle='#e8dcc0'; ctx.fillText('↑ 本を裏返して　近道', 660, 120);
    ctx.fillStyle='rgba(74,70,60,0.95)'; ctx.fillText('→ そのまま　遠回り', 660, 400);
    ctx.globalAlpha=1;
  }
  if(GT.flags.route){
    const txt='進む道：'+(GT.flags.route==='shortcut'?'近道（ひとりで）':'遠回り（赤ずきんと）');
    const w=ctx.measureText(txt).width+28;
    GT.roundRect(W/2-w/2,35,w,26,13); ctx.fillStyle='rgba(43,36,24,0.78)'; ctx.fill();
    ctx.fillStyle='#f3ead0'; ctx.fillText(txt,W/2,49);
  }
  const h=hoodNpc();
  if(st.bubble && h && h.x<W){
    const b=st.bubble, cx=Math.min(W-EDGE-60,h.x+16), y=FLOOR-84;
    ctx.globalAlpha=Math.min(1,b.t*3); ctx.font="700 13px 'Zen Old Mincho',serif";
    const w=ctx.measureText(b.text).width+20;
    GT.roundRect(cx-w/2,y-12,w,24,12); ctx.fillStyle='rgba(250,244,228,0.95)'; ctx.fill();
    ctx.strokeStyle='rgba(139,74,63,0.6)'; ctx.lineWidth=1.4; ctx.stroke();
    ctx.fillStyle='#8b4a3f'; ctx.fillText(b.text,cx,y+1);
  }
  ctx.restore();
}

GT.registerDraw(()=>{ if(!isCross()) return; drawRoutes(); }, 'back');
GT.registerDraw(()=>{ if(!isCross()) return; moveHood(); drawThorns(); drawSign(); drawGuide(); }, 'world');
})();
