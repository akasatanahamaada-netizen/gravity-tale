/* ============================================================================
   ステージ：第一話 ── 近道  id = 'path2'
   種類：play　分かれ道で「近道」を選んだときだけ遊ぶ（遠回りのときは飛ばす）。
         床の壁→天井へ、天井の壁→床へ、のつづら折り（右ページで2回反転）
   担当：
   ========================================================================== */

/* stages/XX_path2.js  ── ステージエディタで作成 */
GT.defineStage('path2', {
  platforms:[
    {page:'left', x:375, y:185, w:20, h:280, kind:'ledge'},
    {page:'right', x:545, y:125, w:150, h:20, kind:'ledge'},
    {page:'left', x:325, y:145, w:120, h:90, kind:'ledge'},
    {page:'left', x:360, y:110, w:65, h:50, kind:'ledge'},
    {page:'right', x:735, y:190, w:115, h:20, kind:'ledge'},
    {page:'right', x:865, y:15, w:20, h:405, kind:'ledge'},
  ],
  boxes:[
    {x:750, y:160, w:32, h:32},
    {x:645, y:80, w:45, h:43},
  ],
  enemies:[
    {page:'right', x:680, y:430, w:36, h:32, dir:-1},
    {page:'right', x:515, y:425, w:41, h:37, dir:-1},
    {page:'right', x:810, y:415, w:30, h:50, dir:-1},
  ],
  decor:[
    {layer:'back', kind:'ledgeBack', x:80, y:270, w:20, h:195},
    {layer:'back', kind:'ledgeBack', x:40, y:230, w:100, h:80},
    {layer:'back', kind:'ledgeBack', x:55, y:200, w:70, h:50},
    {layer:'front', kind:'ledgeFront', x:200, y:155, w:25, h:310},
    {layer:'front', kind:'ledgeFront', x:135, y:70, w:160, h:120},
    {layer:'front', kind:'ledgeFront', x:175, y:30, w:105, h:65},
    {layer:'front', kind:'fern', x:95, y:420, w:50, h:45},
    {layer:'front', kind:'fern', x:140, y:410, w:80, h:55},
    {layer:'front', kind:'fern', x:325, y:415, w:55, h:45},
    {layer:'front', kind:'fern', x:630, y:355, w:130, h:110},
    {layer:'front', kind:'grass', x:585, y:400, w:45, h:59},
    {layer:'front', kind:'fern', x:475, y:385, w:100, h:80},
    {layer:'front', kind:'fern', x:790, y:400, w:75, h:70},
    {layer:'front', kind:'grass', x:745, y:385, w:60, h:79},
  ],
});

GT.registerScene({
  id:'path2', type:'play', stage:'path2', clear:'exit',
  label:'第一話 ── 近道',
  dynamic:'shortcutOnly',   // 近道のときだけ遊ぶ（07_crossroads.js）
  intro:{s:'',c:'narr',t:'右へ進もう。'},
});
