/* ============================================================================
   ステージ：第一話 ── 森の道 ①  id = 'path1'
   種類：play
   担当：
   ----------------------------------------------------------------------------
   ◆ ねらい：重力反転（本を裏返す）を主役にしたステージ
     床はつねに一枚つづきなので「反転しないと通れない」地形は作れない。
     そこで ── 床は手下（敵）で危険にし、反転で縦に大きく移動しながら
     梢（天井ぎわの足場）を渡るのが正解ルートになるようにしてある。
     ※反転は「上／下へ落ちる」ので、ジャンプ(約118px)では届かない
       縦の段差をタダで越えられる。これを前提に段差を大きくとっている。

   ◆ 想定ルート（★＝本を裏返す）
     左ページ：床の隅から ★反転→ 梢CL_a・CL_bを右へ渡る（手下の頭上）
            → ★反転(戻す)→ 中段のL_landに降りる
            → 背表紙をまたいで R_entry（中段の橋）へ
     右ページ：R_entryで ★反転→ 梢CR_a→CR_b→CR_cを右へ渡る（手下の頭上）
            → そのまま右端へ抜けてクリア
     → 左で2回・右で1回、上向き下向き両方の反転を使う構成。

   ◆ 座標メモ（engine.js 由来）
     画面 900×480 / 背表紙 x=450 / 床の上面 y≒464 / ジャンプ到達 約118px
   ========================================================================== */

/* stages/XX_path1.js  ── ステージエディタで作成 */
/* stages/XX_path1.js  ── ステージエディタで作成 */
/* stages/XX_path1.js  ── ステージエディタで作成 */
GT.defineStage('path1', {
  platforms:[
    {page:'left', x:70, y:55, w:80, h:75, kind:'ledge'},
    {page:'left', x:295, y:85, w:105, h:60, kind:'ledge'},
    {page:'left', x:105, y:185, w:15, h:275, kind:'ledge'},
    {page:'left', x:355, y:360, w:55, h:100, kind:'ledge'},
    {page:'right', x:790, y:300, w:20, h:160, kind:'ledge'},
    {page:'right', x:570, y:385, w:15, h:80, kind:'ledge'},
    {page:'right', x:535, y:340, w:90, h:55, kind:'ledge'},
    {page:'right', x:555, y:305, w:50, h:40, kind:'ledge'},
    {page:'right', x:740, y:240, w:120, h:85, kind:'ledge'},
    {page:'right', x:750, y:200, w:100, h:50, kind:'ledge'},
    {page:'right', x:630, y:20, w:50, h:170, kind:'ledge'},
    {page:'right', x:620, y:20, w:60, h:140, kind:'ledge'},
  ],
  boxes:[
    {x:135, y:425, w:40, h:37},
  ],
  enemies:[
    {page:'right', x:740, y:430, w:40, h:30, dir:-1},
    {page:'left', x:195, y:440, w:35, h:20, dir:-1},
  ],
  decor:[
    {layer:'front', kind:'ledgeFront', x:250, y:320, w:130, h:140},
    {layer:'front', kind:'ledgeFront', x:40, y:120, w:140, h:85},
  ],
});

GT.registerScene({
  id:'path1', type:'play', stage:'path1', clear:'exit',
  label:'新ステージ',
  intro:{s:'',c:'narr',t:'右へ進もう。'},
});
